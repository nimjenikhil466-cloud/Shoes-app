import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShoppingBag, 
  MapPin, 
  CreditCard, 
  Layers, 
  Sparkles, 
  Grid, 
  FileText, 
  Laptop, 
  Smartphone, 
  Heart, 
  Compass, 
  Truck, 
  Info,
  LogOut,
  Tag
} from "lucide-react";

import { AppScreen, Shoe, CartItem, Order, OrderStep } from "./types";
import { MOCK_SHOES } from "./data";

// Import core screens
import LoginScreen from "./components/LoginScreen";
import HomeScreen from "./components/HomeScreen";
import PLPScreen from "./components/PLPScreen";
import PDPScreen from "./components/PDPScreen";
import CartScreen from "./components/CartScreen";
import OrdersScreen from "./components/OrdersScreen";

export default function App() {
  // Navigation & User State
  const [currentScreen, setCurrentScreen] = useState<AppScreen>(AppScreen.LOGIN);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [isFullscreenMobile, setIsFullscreenMobile] = useState(false);

  // Parameter State for sub-routes
  const [selectedShoeId, setSelectedShoeId] = useState<string>("shoe_1");
  const [plpFilters, setPlpFilters] = useState<{ category?: string; query?: string; wishlistOnly?: boolean }>({});

  // E-Commerce Data State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>(["shoe_1", "shoe_3"]); // initially seed two popular models
  
  // Seed a realistic active shipment order so the tracking page has instant content
  const [orders, setOrders] = useState<Order[]>([
    {
      id: "vlt-55271",
      items: [
        {
          id: "shoe_1-9-Crimson Red",
          shoe: MOCK_SHOES[0], // Horizon Crimson Red
          selectedSize: 9,
          selectedColor: "Crimson Red",
          quantity: 1
        },
        {
          id: "shoe_4-10-Camel Tan",
          shoe: MOCK_SHOES[3], // Suede Court camel tan
          selectedSize: 10,
          selectedColor: "Camel Tan",
          quantity: 1
        }
      ],
      total: 304,
      date: "Jun 16, 2026",
      expectedDelivery: "Jun 20, 2026, 02:30 PM",
      step: OrderStep.SHIPPED,
      address: {
        fullName: "Nikhil Nimje",
        phoneNumber: "+1 (555) 732-2917",
        addressLine: "452 Neon Sprint Boulevard, Applet Suite 3B",
        city: "Seattle, WA",
        zipCode: "98101"
      }
    }
  ]);

  // Handle auto-scroll to top when screen transitions
  useEffect(() => {
    const activeScrollArea = document.getElementById("mobile-viewport-container");
    if (activeScrollArea) {
      activeScrollArea.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, [currentScreen]);

  // Navigate function with state parameters payload
  const navigateTo = (screen: string, params: any = {}) => {
    if (params.shoeId) {
      setSelectedShoeId(params.shoeId);
    }
    if (params.category !== undefined || params.query !== undefined || params.wishlistOnly !== undefined) {
      setPlpFilters({ 
        category: params.category, 
        query: params.query, 
        wishlistOnly: params.wishlistOnly 
      });
    } else {
      // clear previous Plp search filters if navigating elsewhere
      if (screen === "PLP") {
        setPlpFilters({});
      }
    }
    setCurrentScreen(screen as AppScreen);
  };

  const handleLogin = (email: string) => {
    setUserEmail(email);
    setCurrentScreen(AppScreen.HOME);
  };

  const handleLogout = () => {
    setUserEmail(null);
    setCartItems([]);
    setCurrentScreen(AppScreen.LOGIN);
  };

  // E-Commerce cart state modifiers
  const handleAddToCart = (shoe: Shoe, size: number, color: string, qty: number) => {
    const compositeId = `${shoe.id}-${size}-${color}`;
    setCartItems(prev => {
      const matchIdx = prev.findIndex(item => item.id === compositeId);
      if (matchIdx > -1) {
        const next = [...prev];
        next[matchIdx] = {
          ...next[matchIdx],
          quantity: next[matchIdx].quantity + qty
        };
        return next;
      } else {
        return [...prev, {
          id: compositeId,
          shoe,
          selectedSize: size,
          selectedColor: color,
          quantity: qty
        }];
      }
    });
  };

  const handleRemoveCartItem = (itemId: string) => {
    setCartItems(prev => prev.filter(item => item.id !== itemId));
  };

  const handleUpdateCartQuantity = (itemId: string, qty: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.id === itemId) {
        return { ...item, quantity: qty };
      }
      return item;
    }));
  };

  const handleWishlistToggle = (id: string) => {
    setWishlist(prev => {
      if (prev.includes(id)) {
        return prev.filter(item => item !== id);
      } else {
        return [...prev, id];
      }
    });
  };

  // Convert current cart checklist items to active tracking order
  const handleCheckout = (address: {
    fullName: string;
    phoneNumber: string;
    addressLine: string;
    city: string;
    zipCode: string;
  }) => {
    const totalCartValue = cartItems.reduce((acc, i) => acc + i.shoe.price * i.quantity, 0);
    const orderId = `vlt-${Math.floor(10000 + Math.random() * 90000)}`;
    const today = new Date();
    const formattedDate = today.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    
    // Scheduled 4 days after
    const deliveryDate = new Date(today.getTime() + 4 * 24 * 60 * 60 * 1000);
    const formattedDelivery = `${deliveryDate.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}, 04:00 PM`;

    const newOrder: Order = {
      id: orderId,
      items: cartItems,
      total: totalCartValue,
      date: formattedDate,
      expectedDelivery: formattedDelivery,
      step: OrderStep.ORDERED,
      address
    };

    setOrders(prev => [newOrder, ...prev]);
    setCartItems([]); // flush cart
  };

  const handleCancelOrder = (orderId: string) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
  };

  // Live order stepping updates (simulating dispatch progression in real-time)
  const handleUpdateOrderStep = (orderId: string, newStep: OrderStep) => {
    setOrders(prev => prev.map(o => {
      if (o.id === orderId) {
        return { ...o, step: newStep };
      }
      return o;
    }));
  };

  // Render correct simulated mobile screen
  const renderSimulatedScreen = () => {
    switch (currentScreen) {
      case AppScreen.LOGIN:
        return <LoginScreen onLoginSuccess={handleLogin} />;
      case AppScreen.HOME:
        return (
          <HomeScreen 
            onNavigate={navigateTo} 
            cartCount={cartItems.reduce((sum, i) => sum + i.quantity, 0)}
            userEmail={userEmail || "guest@orbitstep.com"}
            onLogout={handleLogout}
            wishlist={wishlist}
            onToggleWishlist={handleWishlistToggle}
          />
        );
      case AppScreen.PLP:
        return (
          <PLPScreen 
            onNavigate={navigateTo} 
            initialFilters={plpFilters}
            wishlist={wishlist}
            onToggleWishlist={handleWishlistToggle}
          />
        );
      case AppScreen.PDP:
        return (
          <PDPScreen 
            shoeId={selectedShoeId} 
            onNavigate={navigateTo} 
            onAddToCart={handleAddToCart}
            wishlist={wishlist}
            onToggleWishlist={handleWishlistToggle}
          />
        );
      case AppScreen.CART:
        return (
          <CartScreen 
            onNavigate={navigateTo} 
            cartItems={cartItems}
            onRemoveItem={handleRemoveCartItem}
            onUpdateCartQuantity={handleUpdateCartQuantity}
            onCheckout={handleCheckout}
          />
        );
      case AppScreen.ORDERS:
        return (
          <OrdersScreen 
            onNavigate={navigateTo} 
            orders={orders}
            onCancelOrder={handleCancelOrder}
            onUpdateStep={handleUpdateOrderStep}
          />
        );
      default:
        return <LoginScreen onLoginSuccess={handleLogin} />;
    }
  };

  // Calc cart count
  const cartTotalCount = cartItems.reduce((acc, c) => acc + c.quantity, 0);

  return (
    <div id="full-workspace-root" className="min-h-screen bg-slate-950 text-zinc-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white relative overflow-hidden">
      
      {/* Absolute decorative mesh gradients for high-end feel in desktop workspace */}
      <div className="absolute top-[-100px] left-[-100px] w-120 h-120 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none z-0"></div>
      <div className="absolute bottom-[-100px] right-[-100px] w-120 h-120 bg-purple-600/10 rounded-full blur-[140px] pointer-events-none z-0"></div>

      {/* 1. SEAMLESS TOP BRAND STRIP */}
      <header className="border-b border-white/10 bg-white/5 backdrop-blur-xl px-6 py-4 relative z-20 shrink-0">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center shadow-lg shadow-blue-500/15">
              <Compass className="w-5 h-5 text-white animate-spin-slow" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono tracking-widest text-blue-400 block leading-tight font-bold">KICKS PREMIUM</span>
              <h1 className="font-display text-lg font-black italic tracking-tight text-white uppercase mt-0.5">
                ORBIT <span className="text-blue-400">STEP</span>
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Fullscreen simulation switcher */}
            <button
              onClick={() => setIsFullscreenMobile(!isFullscreenMobile)}
              className="hidden md:flex items-center gap-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-850 px-3.5 py-1.5 rounded-lg text-xs font-mono font-medium text-zinc-300 transition-all cursor-pointer"
            >
              {isFullscreenMobile ? (
                <>
                  <Laptop className="w-3.5 h-3.5 text-rose-400" />
                  Companion Split mode
                </>
              ) : (
                <>
                  <Smartphone className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                  Full Immersive Mobile Canvas
                </>
              )}
            </button>

            <span className="text-zinc-600 text-[11px] font-mono hidden sm:inline">
              CLIENT EST: 2026 UTC
            </span>
          </div>
        </div>
      </header>

      {/* 2. DUAL-COLUMN INTERACTIVE CONTENT BODY */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 md:px-6 py-6 flex flex-col lg:flex-row items-stretch gap-6">
        
        {/* LEFT COLUMN: ARCHITECTURAL COMPANION LOGS & CODES (hidden if client toggles fullscreen mode) */}
        {!isFullscreenMobile && (
          <div 
            id="companion-panel-left"
            className="w-full lg:w-[35%] flex flex-col gap-5 justify-between shrink-0 self-start"
          >
            {/* Quick specifications blueprint */}
            <div className="glass-panel p-5 rounded-2xl space-y-4">
              <div className="flex items-center gap-2 text-blue-400">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-display font-black text-sm uppercase tracking-wider italic">
                  E-Commerce Blueprint
                </h3>
              </div>

              <p className="text-zinc-400 text-xs leading-relaxed font-sans">
                Welcome to the production-ready <strong>Orbit Step Footwear E-commerce portal</strong>. It features pixel-perfect responsive layouts designed by expert mobile app decorators. Built purely utilizing <strong>React + Vite + Tailwind CSS v4</strong> and <strong>Framer Motion</strong>.
              </p>

              {/* Promo Cheat sheet list */}
              <div className="bg-[#020617]/50 p-4 rounded-xl border border-white/10 space-y-2.5">
                <span className="text-[9px] uppercase font-mono text-blue-400 font-bold block mb-1">Coupon codes available</span>
                
                <div className="flex items-center justify-between text-xs font-mono bg-zinc-900/60 p-2 rounded border border-zinc-800">
                  <span className="font-bold text-teal-400 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-teal-400" />
                    ORBIT20
                  </span>
                  <span className="text-zinc-500 font-medium">Allows 20% OFF</span>
                </div>

                <div className="flex items-center justify-between text-xs font-mono bg-zinc-900/60 p-2 rounded border border-zinc-800">
                  <span className="font-bold text-purple-400 flex items-center gap-1">
                    <Tag className="w-3.5 h-3.5 text-purple-400" />
                    SNEAKER10
                  </span>
                  <span className="text-zinc-500 font-medium">Allows 10% OFF</span>
                </div>
              </div>

              <div className="h-[1px] bg-zinc-900" />

              {/* Telemetry data list */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono text-zinc-500 block font-semibold">Gateway Telemetry Stats</span>
                
                <div className="grid grid-cols-2 gap-2 text-center">
                  <div className="bg-[#020617]/50 p-2.5 rounded-lg border border-white/10">
                    <span className="text-zinc-500 text-[9px] uppercase font-mono block">Cart size</span>
                    <span className="text-white font-mono text-md font-bold">{cartTotalCount} items</span>
                  </div>

                  <div className="bg-[#020617]/50 p-2.5 rounded-lg border border-white/10">
                    <span className="text-zinc-500 text-[9px] uppercase font-mono block">Saved styles</span>
                    <span className="text-blue-400 font-mono text-md font-bold flex justify-center items-center gap-1">
                      <Heart className="w-3.5 h-3.5 fill-blue-500 text-blue-500" />
                      {wishlist.length} models
                    </span>
                  </div>

                  <div className="bg-[#020617]/50 p-2.5 rounded-lg border border-white/10 col-span-2">
                    <span className="text-zinc-500 text-[9px] uppercase font-mono block">Trackable Orders</span>
                    <span className="text-emerald-400 font-mono text-xs font-bold">{orders.length} deliveries registered</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick navigation flow directory */}
            <div className="glass-panel p-5 rounded-2xl space-y-3.5">
              <span className="text-[10px] uppercase font-mono text-zinc-500 tracking-wider font-bold block">
                Quick Navigate Sandbox
              </span>

              <div className="grid grid-cols-2 gap-2 text-left">
                {[
                  { lbl: "1. Lockscreen", target: AppScreen.LOGIN, icon: <Layers className="w-4 h-4 text-blue-400" /> },
                  { lbl: "2. Dashboard", target: AppScreen.HOME, icon: <Grid className="w-4 h-4 text-blue-400" /> },
                  { lbl: "3. Catalog PLP", target: AppScreen.PLP, icon: <Compass className="w-4 h-4 text-blue-400" /> },
                  { lbl: "4. Details PDP", target: AppScreen.PDP, icon: <FileText className="w-4 h-4 text-blue-400" /> },
                  { lbl: "5. Cart basket", target: AppScreen.CART, icon: <ShoppingBag className="w-4 h-4 text-blue-400" /> },
                  { lbl: "6. Track Shipment", target: AppScreen.ORDERS, icon: <Truck className="w-4 h-4 text-blue-400" /> }
                ].map((sc) => {
                  const isActive = currentScreen === sc.target;
                  return (
                    <button
                      key={sc.lbl}
                      onClick={() => {
                        // Check if auth bypass is needed
                        if (!userEmail && sc.target !== AppScreen.LOGIN) {
                          setUserEmail("admin@orbitstep.com");
                        }
                        setCurrentScreen(sc.target);
                      }}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold hover:border-white/20 transition-all cursor-pointer ${isActive ? "bg-blue-600/20 border-blue-500 text-blue-400 shadow-md shadow-blue-500/5" : "bg-white/5 border-white/10 text-zinc-350"}`}
                    >
                      {sc.icon}
                      {sc.lbl}
                    </button>
                  );
                })}
              </div>

              {/* Warning to log in */}
              {!userEmail && (
                <div className="p-2.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400 text-[10px] flex items-center gap-1 leading-normal font-sans">
                  <Info className="w-4 h-4 shrink-0" />
                  <span>Use guest skip inside login screen to experience full permissions.</span>
                </div>
              )}
            </div>
            
            {/* Brand credentials */}
            <div className="text-[11px] text-zinc-600 font-mono flex items-center justify-between px-2">
              <span>DESIGNED FOR MOBILE UX</span>
              <span>SECURE PROTOCOLS APPLIED</span>
            </div>
          </div>
        )}

        {/* RIGHT COLUMN: SIMULATED MOBILE viewport frame inside a titanium frame! */}
        <div 
          id="mobile-simulator-wrapper-outer"
          className={`flex-1 flex justify-center items-center transition-all duration-500 ${isFullscreenMobile ? "w-full" : ""}`}
        >
          {/* Real Titanium Phone simulator Frame */}
          <div 
            id="simulated-device-bezel"
            className={`w-full max-w-[420px] rounded-[42px] border-[12px] border-zinc-800 bg-zinc-950 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.85)] overflow-hidden flex flex-col relative transition-all duration-300 ${isFullscreenMobile ? "max-w-[430px] border-zinc-900 ring-4 ring-zinc-850/40" : ""}`}
            style={{ height: "85vh", minHeight: "740px" }}
          >
            
            {/* Phone Top Speaker/Sensor Notch Detail */}
            <div className="absolute top-0 inset-x-0 h-7 bg-zinc-800 z-50 flex justify-center items-start">
              <div className="w-28 h-4.5 bg-black rounded-b-2xl flex items-center justify-between px-2">
                {/* Simulated pill sensor */}
                <div className="w-2 h-2 rounded-full bg-zinc-900" />
                <div className="w-14 h-1 bg-zinc-850 rounded-full" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 animate-pulse" />
              </div>
            </div>

            {/* Simulated Mobile Status bar */}
            <div className="h-11 bg-zinc-950 pt-6 px-6 flex justify-between items-center text-[10px] text-zinc-400 font-mono select-none z-40 relative">
              <span>9:41 AM</span>
              <div className="flex items-center gap-1.5">
                <span className="text-emerald-500 font-bold">5G</span>
                <span className="text-zinc-650">•</span>
                {/* 100% battery */}
                <div className="w-5.5 h-2.5 border border-zinc-500 rounded p-[1px] flex items-center">
                  <div className="w-full h-full bg-emerald-400 rounded-xs" />
                </div>
              </div>
            </div>

            {/* LIVE PORTAL VIEWPORT SCROLL CONTAINER */}
            <div 
              id="mobile-viewport-container"
              className="flex-1 overflow-y-auto no-scrollbar bg-slate-950/90 backdrop-blur-3xl p-4 md:p-5 relative"
            >
              {/* Internal Mesh Glow Backgrounds */}
              <div className="absolute top-[-40px] left-[-40px] w-56 h-56 bg-blue-600/15 rounded-full blur-[70px] pointer-events-none z-0"></div>
              <div className="absolute bottom-[-40px] right-[-40px] w-56 h-56 bg-purple-600/15 rounded-full blur-[70px] pointer-events-none z-0"></div>
              
              <div className="relative z-10 h-full">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentScreen}
                    initial={{ opacity: 0, x: 15 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -15 }}
                    transition={{ duration: 0.3 }}
                    className="h-full"
                  >
                    {renderSimulatedScreen()}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            {/* Mobile Bottom Navigation Pill Indicator bar */}
            <div className="h-6 bg-zinc-950 flex justify-center items-center pb-2 z-40 select-none relative">
              <div className="w-32 h-1 bg-zinc-700 rounded-full" />
            </div>

          </div>
        </div>

      </main>

      {/* 3. PREMIUM FOOTER ACCENTS */}
      <footer className="border-t border-zinc-950 bg-black/60 px-6 py-4 relative z-20 text-zinc-600 text-xs shrink-0 select-none">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="font-display font-medium text-[11px] tracking-wider text-zinc-500">
              © 2026 ORBIT STEP LABS INC.
            </span>
            <span className="text-zinc-850">|</span>
            <span className="font-sans text-[10px] text-zinc-600">
              Strictly Secure Sandbox Testing
            </span>
          </div>

          <div className="flex items-center gap-4 text-[10px] font-mono tracking-wider">
            <span>PLATFORM: REACT + TS</span>
            <span className="text-zinc-800">•</span>
            <span>INGRESS PORT: 3000 Verified</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
