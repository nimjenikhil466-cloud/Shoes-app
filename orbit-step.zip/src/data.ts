import { Shoe } from "./types";

export const BRANDS = ["AeroStride", "NovaFit", "Veloce", "Equinox", "Crown Leather"];
export const CATEGORIES = ["Sneakers", "Sports", "Casual", "Formal"];
export const ALL_SIZES = [7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 12];

export const MOCK_SHOES: Shoe[] = [
  {
    id: "shoe_1",
    name: "Air-Max Horizon Crimson",
    brand: "AeroStride",
    category: "Sneakers",
    price: 189,
    originalPrice: 220,
    rating: 4.8,
    reviewsCount: 342,
    description: "Designed with modern city explorers in mind. The Air-Max Horizon Crimson offers unmatched comfort, utilizing dual-density nitrogen-infused foam coupled with a responsive crimson performance heel unit. The upper is woven with recycled PrimeWeave mesh for superior breathability and a high-tech sock-like fit.",
    images: [
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [8, 8.5, 9, 9.5, 10, 10.5, 11],
    colors: [
      { name: "Crimson Red", hex: "#EF4444" },
      { name: "Volt Green", hex: "#84CC16" },
      { name: "Cosmic Black", hex: "#111827" }
    ],
    featured: true,
    trending: true,
    bannerImage: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1200&auto=format&fit=crop",
    details: {
      material: "75% Recycled Polyester PrimeWeave mesh, high-abrasion rubber pods, TPU stabilizer clip.",
      care: "Wipe with a damp cloth or soft sponge. Do not machine wash. Air dry away from direct heat and sunlight.",
      returns: "Free returns within 30 days of purchase in original packaging and unworn condition."
    }
  },
  {
    id: "shoe_2",
    name: "Veloce Volt Runner",
    brand: "Veloce",
    category: "Sports",
    price: 145,
    originalPrice: 170,
    rating: 4.9,
    reviewsCount: 198,
    description: "Built for speed and high-intensity athletics. The Volt Runner incorporates Veloce's CarbonPlate system for a powerful energy return on every strike. This ultra-lightweight sneaker cuts down drag and features an adaptive heel counter that secures your gait over long distances.",
    images: [
      "https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [7, 8, 8.5, 9, 9.5, 10, 11, 12],
    colors: [
      { name: "Volt Green", hex: "#10B981" },
      { name: "Neon Blue", hex: "#3B82F6" },
      { name: "Pitch Gray", hex: "#4B5563" }
    ],
    featured: false,
    trending: true,
    details: {
      material: "Ultralight Monofilament Weave, carbon-fiber infused midsole, duralon rubber forefoot.",
      care: "Remove insole and laces before using soft cleaning brush. Use warm water with standard sneaker soap.",
      returns: "Enjoy a 30-day wear test. If it doesn't fit your stride, return for exchange or store refund."
    }
  },
  {
    id: "shoe_3",
    name: "Retro Aurora High-Top",
    brand: "NovaFit",
    category: "Sneakers",
    price: 165,
    rating: 4.7,
    reviewsCount: 512,
    description: "Nostalgic aesthetics meet contemporary padding. Inspired by the legendary courts of the 1990s, the Retro Aurora High-Top features premium tumbled leather overlays paired with stunning pastel accent panels. The padded high-top collar provides excellent ankle security and ultimate lifestyle appeal.",
    images: [
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11],
    colors: [
      { name: "Aurora Lilac & Teal", hex: "#A78BFA" },
      { name: "Sunset Gold", hex: "#F59E0B" },
      { name: "Classic White", hex: "#FFFFFF" }
    ],
    featured: true,
    trending: false,
    bannerImage: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1200&auto=format&fit=crop",
    details: {
      material: "Full-grain tumbled leather cowhide, memory foam cushioning orthotic, cupsole non-marking rubber.",
      care: "Use specialized leather cream and a micro-fiber cloth to maintain hydration. Do not soak in water.",
      returns: "Eligible for free returns and custom size swap exchanges within 30 days."
    }
  },
  {
    id: "shoe_4",
    name: "Suede Court Classic",
    brand: "Equinox",
    category: "Casual",
    price: 115,
    originalPrice: 130,
    rating: 4.6,
    reviewsCount: 227,
    description: "An understated wardrobe staple for every modern minimalist. Crafted in premium Italian cowhide suede, these low-profile court shoes elevate simple denim or polished trousers. Features vulcanized low-vibration waffle outsoles and a supportive moisture-wicking cork layer.",
    images: [
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [8, 9, 10, 11, 12],
    colors: [
      { name: "Camel Tan", hex: "#D97706" },
      { name: "Midnight Navy", hex: "#1E3A8A" },
      { name: "Charcoal Dust", hex: "#374151" }
    ],
    featured: false,
    trending: true,
    details: {
      material: "100% Suede leather upper, eco-cork footbed lining, durable vulcanized rubber outsole.",
      care: "Brush exclusively with a soft suede wire brush. Treat periodically with waterproofing spray.",
      returns: "Complimentary return shipping. Must be returned in pristine, unscuffed condition."
    }
  },
  {
    id: "shoe_5",
    name: "Oxford Heritage Brogue",
    brand: "Crown Leather",
    category: "Formal",
    price: 240,
    originalPrice: 285,
    rating: 4.9,
    reviewsCount: 88,
    description: "The peak of sartorial elegance. Featuring meticulously punched wingtip broguiying details, the Oxford Heritage Brogue is handmade in small batches in Florence. Its Goodyear welted structure allows for easy lifetime resoling, while the vegetable-tanned lining molds beautifully to your foot over time.",
    images: [
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11],
    colors: [
      { name: "Mahogany Brown", hex: "#78350F" },
      { name: "Onyx Black", hex: "#030712" }
    ],
    featured: false,
    trending: false,
    details: {
      material: "Hand-finished Italian box-calf leather, vegetable-tanned lining, premium double oak leather sole.",
      care: "Apply premium wax polish and buff with horsehair brush. Use cedar wooden shoe trees to maintain shape.",
      returns: "Free returns, please test only on carpeted floors to prevent scoring and scratching leather soles."
    }
  },
  {
    id: "shoe_6",
    name: "Apex Hybrid Trail Blazer",
    brand: "Veloce",
    category: "Sports",
    price: 155,
    rating: 4.7,
    reviewsCount: 144,
    description: "Engineered to dominate rough gravel and city asphalt alike. The Apex Trail Blazer marries a fully seam-sealed ripstop grid body with a fierce multi-directional claw lug outsole. An integrated neoprene gaiter collar locks out mud, moisture, and trail debris so you can power forward with complete confidence.",
    images: [
      "https://images.unsplash.com/photo-1608231387042-66d1773070a5?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=600&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop"
    ],
    sizes: [8, 8.5, 9, 9.5, 10, 10.5, 11, 12],
    colors: [
      { name: "Desert Sand & Olive", hex: "#854D0E" },
      { name: "Cyberpunk Volt", hex: "#A3E635" },
      { name: "Black Shadow", hex: "#1F2937" }
    ],
    featured: false,
    trending: true,
    details: {
      material: "Gore-Tex water repellent shell, double-knit neoprene collar, carbon rubber rugged sole.",
      care: "Hose off dried mud, wash with neutral soap and warm water. Let air dry naturally under shady cover.",
      returns: "Comes with standard e-commerce 30-day warranty."
    }
  }
];
