import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, Phone, ArrowRight, ShieldCheck, ShoppingBag } from "lucide-react";

interface LoginScreenProps {
  onLoginSuccess: (emailOrPhone: string) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [inputValue, setInputValue] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState(["", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const isEmail = inputValue.includes("@");
  const isPhone = /^\+?[0-9]{8,15}$/.test(inputValue.replace(/\s+/g, ""));
  const isValidIdentifier = inputValue.trim().length > 4 && (isEmail || /^[0-9+() -]+$/.test(inputValue));

  const handleSendOTP = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isValidIdentifier) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setOtpSent(true);
    }, 1200);
  };

  const verifyOTP = (e: React.FormEvent) => {
    e.preventDefault();
    const enteredCode = otpCode.join("");
    if (enteredCode.length < 4) {
      setErrorMsg("Please fill in the 4-digit verification code.");
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoginSuccess(inputValue || "guest@premiumshoes.com");
    }, 1000);
  };

  const handleOtpChange = (index: number, val: string) => {
    if (!/^[0-9]?$/.test(val)) return;
    const newOtp = [...otpCode];
    newOtp[index] = val;
    setOtpCode(newOtp);

    // Auto-focus next field
    if (val !== "" && index < 3) {
      const nextInput = document.getElementById(`otp-input-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && otpCode[index] === "" && index > 0) {
      const prevInput = document.getElementById(`otp-input-${index - 1}`);
      prevInput?.focus();
    }
  };

  return (
    <div 
      id="login-screen-bg"
      className="relative min-h-[85vh] md:min-h-[750px] w-full rounded-3xl overflow-hidden flex flex-col justify-center items-center px-4 md:px-8 py-10 bg-cover bg-center"
      style={{
        backgroundImage: "url('https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=1000&auto=format&fit=crop')"
      }}
    >
      {/* Dark Overlay for branding contrast */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-slate-950/60 z-0" />

      {/* Decorative Blur Spheres in BG - Frosted Glass Mockup colors */}
      <div className="absolute top-1/4 -right-12 w-80 h-80 bg-blue-600/15 rounded-full blur-[110px] pointer-events-none z-0" />
      <div className="absolute bottom-1/4 -left-12 w-80 h-80 bg-purple-600/15 rounded-full blur-[110px] pointer-events-none z-0" />

      {/* Content wrapper */}
      <div className="relative z-10 w-full max-w-sm flex flex-col items-center">
        {/* App Logo */}
        <motion.div 
          id="login-logo-container"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center gap-2 mb-8"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-purple-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <ShoppingBag className="w-5 h-5 text-white" />
          </div>
          <span className="font-display text-xl font-bold tracking-tight text-white uppercase">
            ORBIT STEP<span className="text-blue-400">.</span>
          </span>
        </motion.div>

        {/* Glassmorphic Floating Card */}
        <motion.div
          id="login-glass-card"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="w-full glass-panel rounded-[2rem] p-6 md:p-8 relative overflow-hidden"
        >
          {/* Subdued geometric light edge */}
          <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-transparent via-blue-500/40 to-transparent" />

          <AnimatePresence mode="wait">
            {!otpSent ? (
              <motion.div
                key="input-stage"
                initial={{ opacity: 0, x: -30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 30 }}
                transition={{ duration: 0.3 }}
              >
                <h2 className="font-display text-2xl font-bold text-white tracking-tight leading-tight">
                  Welcome to Orbit Step
                </h2>
                <p className="text-zinc-400 text-xs mt-1 mb-6">
                  Enter your mobile number or email to proceed securely. No password required.
                </p>

                <form onSubmit={handleSendOTP} className="space-y-4">
                  <div className="relative">
                    <label className="text-[10px] uppercase tracking-wider text-blue-400 font-semibold block mb-1">
                      Email or Phone Number
                    </label>
                    <div className="relative">
                      {inputValue.includes("@") ? (
                        <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-blue-400" />
                      ) : (
                        <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-zinc-400" />
                      )}
                      <input
                        type="text"
                        placeholder="e.g. nikhil@orbitstep.com or +12345678"
                        value={inputValue}
                        onChange={(e) => setInputValue(e.target.value)}
                        className="w-full bg-white/5 backdrop-blur-md text-sm text-white px-10 py-3 rounded-xl border border-white/10 focus:outline-none focus:border-blue-500/80 transition-all font-sans placeholder-zinc-500"
                        autoFocus
                      />
                    </div>
                  </div>

                  {/* Dynamic send button appearing smoothly */}
                  <AnimatePresence>
                    {isValidIdentifier && (
                      <motion.button
                        id="btn-send-otp"
                        type="submit"
                        disabled={loading}
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-sm font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-blue-600/20 transition-all active:scale-[0.98] cursor-pointer mt-4"
                      >
                        {loading ? (
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <>
                            Send Access Code <ArrowRight className="w-4 h-4" />
                          </>
                        )}
                      </motion.button>
                    )}
                  </AnimatePresence>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="otp-stage"
                initial={{ opacity: 0, x: 30 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -30 }}
                transition={{ duration: 0.3 }}
              >
                <div className="flex items-center gap-2 mb-4">
                  <ShieldCheck className="w-6 h-6 text-emerald-400" />
                  <h2 className="font-display text-2xl font-bold text-white tracking-tight">
                    Enter OTP
                  </h2>
                </div>
                <p className="text-zinc-400 text-xs mb-6">
                  We sent a 4-digit code to <span className="text-blue-400 font-medium">{inputValue}</span>. Enter code below to sign in.
                </p>

                <form onSubmit={verifyOTP} className="space-y-5">
                  <div className="flex justify-center gap-3">
                    {otpCode.map((digit, idx) => (
                      <input
                        key={idx}
                        id={`otp-input-${idx}`}
                        type="text"
                        maxLength={1}
                        value={digit}
                        onChange={(e) => handleOtpChange(idx, e.target.value)}
                        onKeyDown={(e) => handleKeyDown(idx, e)}
                        className="w-12 h-14 bg-white/5 text-xl font-bold text-center text-white border border-white/10 rounded-xl focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500/30 transition-all"
                        placeholder="•"
                      />
                    ))}
                  </div>

                  {errorMsg && (
                    <div className="text-rose-400 text-xs text-center">{errorMsg}</div>
                  )}

                  <button
                    id="btn-verify-otp"
                    type="submit"
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-sm font-bold py-3.5 px-4 rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-[0.98] cursor-pointer"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      "Confirm & Sign In"
                    )}
                  </button>

                  <div className="text-center">
                    <button
                      type="button"
                      onClick={() => setOtpSent(false)}
                      className="text-zinc-400 hover:text-white text-xs underline transition-colors"
                    >
                      Change phone / email
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Quick skip for testing */}
          <div className="mt-6 pt-5 border-t border-white/5 flex flex-col items-center">
            <span className="text-zinc-500 text-[11px] uppercase tracking-wider mb-2">Or quick entry</span>
            <button
              id="btn-fast-skip"
              type="button"
              onClick={() => onLoginSuccess("guest@orbitstep.com")}
              className="text-blue-400 hover:text-blue-350 text-xs font-semibold flex items-center gap-1.5 hover:underline decoration-blue-400/30 font-sans"
            >
              Demo Guest Login <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>

        {/* Social logins */}
        <motion.div
          id="social-login-panel"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-8 flex flex-col items-center gap-4 w-full"
        >
          <div className="flex items-center gap-3 w-full justify-center">
            <div className="h-[1px] w-12 bg-zinc-800" />
            <span className="text-zinc-500 text-xs uppercase tracking-wider font-mono">Instant Social Login</span>
            <div className="h-[1px] w-12 bg-zinc-800" />
          </div>

          <div className="flex gap-4">
            {/* Google */}
            <button 
              type="button"
              onClick={() => onLoginSuccess("guser@google.com")}
              className="w-12 h-12 rounded-full glass-panel flex items-center justify-center hover:bg-zinc-800/80 hover:scale-105 transition-all text-white border border-white/10 shadow-lg cursor-pointer"
              title="Sign in with Google"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l3.66-2.85z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
            </button>

            {/* Apple */}
            <button 
              type="button"
              onClick={() => onLoginSuccess("appleuser@apple.com")}
              className="w-12 h-12 rounded-full glass-panel flex items-center justify-center hover:bg-zinc-800/80 hover:scale-105 transition-all text-white border border-white/10 shadow-lg cursor-pointer"
              title="Sign in with Apple"
            >
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M15.97 4.17c.66-.81 1.11-1.93.99-3.05-1 .04-2.21.67-2.93 1.49-.62.69-1.16 1.84-1.01 2.94 1.11.09 2.25-.57 2.95-1.38z" />
              </svg>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
