import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Star, Heart, ArrowLeft, SlidersHorizontal, X, ArrowUpDown, Filter, RotateCcw } from "lucide-react";
import { Shoe } from "../types";
import { MOCK_SHOES, BRANDS, CATEGORIES, ALL_SIZES } from "../data";

interface PLPScreenProps {
  onNavigate: (screen: string, params?: any) => void;
  initialFilters?: {
    category?: string;
    query?: string;
    wishlistOnly?: boolean;
  };
  wishlist: string[];
  onToggleWishlist: (id: string) => void;
}

export default function PLPScreen({ 
  onNavigate, 
  initialFilters = {}, 
  wishlist,
  onToggleWishlist
}: PLPScreenProps) {
  // Filters State
  const [selectedCategory, setSelectedCategory] = useState<string | null>(initialFilters.category || null);
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [selectedSize, setSelectedSize] = useState<number | null>(null);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [maxPrice, setMaxPrice] = useState<number>(300);
  const [sortBy, setSortBy] = useState<string>("popular");

  // Filter Modal Toggle
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Available unique colors aggregated from mock database
  const availableColors = useMemo(() => {
    const colorsMap = new Map<string, string>();
    MOCK_SHOES.forEach(shoe => {
      shoe.colors.forEach(col => {
        colorsMap.set(col.name, col.hex);
      });
    });
    return Array.from(colorsMap.entries()).map(([name, hex]) => ({ name, hex }));
  }, []);

  // Filter & Sort Logic
  const processedShoes = useMemo(() => {
    let result = [...MOCK_SHOES];

    // Filter by initial wishlistOnly request
    if (initialFilters.wishlistOnly) {
      result = result.filter(s => wishlist.includes(s.id));
    }

    // Filter by Search Query
    if (initialFilters.query) {
      const q = initialFilters.query.toLowerCase();
      result = result.filter(s => 
        s.name.toLowerCase().includes(q) || 
        s.brand.toLowerCase().includes(q) || 
        s.category.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q)
      );
    }

    // Filter by Category
    if (selectedCategory) {
      result = result.filter(s => s.category === selectedCategory);
    }

    // Filter by Brand
    if (selectedBrand) {
      result = result.filter(s => s.brand === selectedBrand);
    }

    // Filter by Size
    if (selectedSize) {
      result = result.filter(s => s.sizes.includes(selectedSize));
    }

    // Filter by Color
    if (selectedColor) {
      result = result.filter(s => s.colors.some(c => c.name === selectedColor));
    }

    // Filter by Price Limit
    result = result.filter(s => s.price <= maxPrice);

    // Sort
    if (sortBy === "popular") {
      // rating as multiplier
      result.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === "price-asc") {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === "price-desc") {
      result.sort((a, b) => b.price - a.price);
    } else if (sortBy.includes("rating")) {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [selectedCategory, selectedBrand, selectedSize, selectedColor, maxPrice, sortBy, initialFilters, wishlist]);

  const activeFiltersCount = useMemo(() => {
    let count = 0;
    if (selectedCategory) count++;
    if (selectedBrand) count++;
    if (selectedSize) count++;
    if (selectedColor) count++;
    if (maxPrice < 300) count++;
    return count;
  }, [selectedCategory, selectedBrand, selectedSize, selectedColor, maxPrice]);

  const resetAllFilters = () => {
    setSelectedCategory(null);
    setSelectedBrand(null);
    setSelectedSize(null);
    setSelectedColor(null);
    setMaxPrice(300);
    setSortBy("popular");
  };

  return (
    <div id="plp-screen-wrapper" className="space-y-6 pb-24 relative min-h-[70vh]">
      
      {/* HEADER BAR */}
      <div className="flex items-center justify-between pb-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <button
            id="btn-plp-back"
            onClick={() => onNavigate("HOME")}
            className="p-2 mr-1 rounded-xl bg-white/5 border border-white/10 text-zinc-400 hover:text-white transition-all cursor-pointer hover:bg-white/10"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-display text-xl font-bold text-white tracking-tight">
              {initialFilters.wishlistOnly ? "My Wishlist" : initialFilters.query ? `Results: "${initialFilters.query}"` : selectedCategory || "All Inventory"}
            </h1>
            <span className="text-zinc-500 text-xs font-mono">
              {processedShoes.length} models found
            </span>
          </div>
        </div>

        {activeFiltersCount > 0 && (
          <button
            onClick={resetAllFilters}
            className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1 font-semibold transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset ({activeFiltersCount})
          </button>
        )}
      </div>

      {/* QUICK CATEGORY PILLS (horizontal scrollable list) */}
      {!initialFilters.wishlistOnly && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          <button
            onClick={() => setSelectedCategory(null)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold tracking-tight transition-all cursor-pointer border ${!selectedCategory ? "bg-blue-600 text-white border-blue-600" : "bg-white/5 text-zinc-300 border-white/10 hover:text-white hover:bg-white/10"}`}
          >
            All Products
          </button>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold tracking-tight whitespace-nowrap transition-all cursor-pointer border ${selectedCategory === cat ? "bg-blue-600 text-white border-blue-600" : "bg-white/5 text-zinc-300 border-white/10 hover:text-white hover:bg-white/10"}`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* PRODUCT GRID (Scannable 2-Column Grid) */}
      {processedShoes.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600">
            <SlidersHorizontal className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white">No models match filters</h3>
            <p className="text-zinc-500 text-xs max-w-xs">
              Try readjusting your budget, sizes selection, styles, or reset your filters.
            </p>
          </div>
          <button
            onClick={resetAllFilters}
            className="bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold py-2 px-4 rounded-xl transition-all cursor-pointer"
          >
            Clear Selected Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 md:gap-4 select-none">
          {processedShoes.map((shoe) => {
            const isWishlisted = wishlist.includes(shoe.id);
            return (
              <div
                key={shoe.id}
                onClick={() => onNavigate("PDP", { shoeId: shoe.id })}
                className="group relative glass-panel rounded-3xl p-3 flex flex-col justify-between cursor-pointer transition-all duration-300 hover:border-white/20 hover:shadow-lg hover:-translate-y-0.5 overflow-hidden"
              >
                {/* Wishlist Icon */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleWishlist(shoe.id);
                  }}
                  className="absolute top-2.5 right-2.5 p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-400 hover:text-blue-400 z-10 transition-colors cursor-pointer"
                  title="Toggle wishlist"
                >
                  <Heart className={`w-3.5 h-3.5 ${isWishlisted ? "fill-blue-500 text-blue-500" : ""}`} />
                </button>

                {/* Main Product Info Block */}
                <div>
                  {/* Photo area */}
                  <div className="w-full h-28 md:h-36 relative bg-zinc-950 rounded-xl overflow-hidden flex items-center justify-center p-2 mb-3">
                    <img
                      src={shoe.images[0]}
                      alt={shoe.name}
                      className="max-h-full max-w-full object-contain -rotate-6 group-hover:-rotate-12 group-hover:scale-105 transition-all duration-300"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Brand and Stars */}
                  <div className="flex justify-between items-center text-[10px] mb-1">
                    <span className="text-blue-400 font-mono tracking-wider uppercase font-semibold">{shoe.brand}</span>
                    <span className="text-zinc-500 flex items-center gap-0.5 font-mono">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      {shoe.rating}
                    </span>
                  </div>

                  {/* Product Title */}
                  <h4 className="font-display text-xs md:text-sm font-bold text-white tracking-tight truncate mb-2">
                    {shoe.name}
                  </h4>
                </div>

                {/* Bottom Bar: Price */}
                <div className="flex items-center justify-between border-t border-white/5 pt-2 bg-gradient-to-t from-white/5 to-transparent">
                  <div className="flex items-baseline gap-1">
                    <span className="text-blue-400 font-display font-extrabold text-sm md:text-base">${shoe.price}</span>
                    {shoe.originalPrice && (
                      <span className="text-zinc-650 line-through text-[10px] font-mono">${shoe.originalPrice}</span>
                    )}
                  </div>
                  
                  {/* Reusable mini CTA action */}
                  <span className="text-[10px] uppercase font-mono font-bold text-zinc-500 group-hover:text-blue-400 transition-colors">
                    View
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* FLOATING ACTION BOTTOM CONSOLE: Filter & Sort Trigger */}
      <div 
        id="plp-floating-action-container"
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2"
      >
        <button
          id="btn-trigger-filter"
          onClick={() => setIsFilterOpen(true)}
          className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-xl border border-white/20 hover:border-white/40 hover:bg-slate-800 text-white text-xs font-semibold py-3 px-6 rounded-full shadow-2xl transition-all cursor-pointer"
        >
          <SlidersHorizontal className="w-4 h-4 text-blue-400" />
          Filter & Sort {activeFiltersCount > 0 && `(${activeFiltersCount})`}
        </button>

        <select
          id="select-plp-sort"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="bg-slate-900/80 backdrop-blur-xl border border-white/20 hover:border-white/40 hover:bg-slate-800 text-white text-xs font-semibold py-3 px-4 rounded-full shadow-2xl focus:outline-none cursor-pointer appearance-none text-center inline-flex items-center pr-8 relative"
          style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' fill=\'none\' viewBox=\'0 0 24 24\' stroke=\'%2360a5fa\'%3E%3Cpath stroke-linecap=\'round\' stroke-linejoin=\'round\' stroke-width=\'2\' d=\'M8 9l4-4 4 4m0 6l-4 4-4-4\'/%3E%3C/svg%3E")', backgroundPosition: 'right 12px center', backgroundSize: '12px', backgroundRepeat: 'no-repeat' }}
        >
          <option value="popular">Popularity</option>
          <option value="price-asc">Price: Low to High</option>
          <option value="price-desc">Price: High to Low</option>
          <option value="rating">Top Rated</option>
        </select>
      </div>

      {/* INTERACTIVE FULL FILTER OVERLAY MODAL */}
      <AnimatePresence>
        {isFilterOpen && (
          <div className="fixed inset-0 bg-black/75 z-50 flex justify-end">
            {/* Modal backdrop click */}
            <motion.div 
              className="absolute inset-0" 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsFilterOpen(false)}
            />

            {/* Filter Content Card */}
            <motion.div
              id="filter-modal-card"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="relative w-full max-w-sm h-full bg-slate-950/95 backdrop-blur-3xl border-l border-white/10 p-6 flex flex-col justify-between overflow-y-auto no-scrollbar z-10 text-white"
            >
              <div>
                {/* Header title */}
                <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
                  <div className="flex items-center gap-2">
                    <Filter className="w-5 h-5 text-blue-400" />
                    <h2 className="font-display text-lg font-bold">Refine Collection</h2>
                  </div>
                  <button
                    onClick={() => setIsFilterOpen(false)}
                    className="p-1 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer border border-white/10"
                  >
                    <X className="w-4 h-4 text-zinc-400" />
                  </button>
                </div>

                {/* Filter segments container */}
                <div className="space-y-6">
                  
                  {/* Category Filter */}
                  <div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 block mb-2.5">Category</span>
                    <div className="grid grid-cols-2 gap-2">
                      {CATEGORIES.map(cat => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategory(selectedCategory === cat ? null : cat)}
                          className={`py-2 px-3 rounded-lg text-xs leading-none font-semibold border text-center transition-all cursor-pointer ${selectedCategory === cat ? "bg-blue-600 border-blue-600 text-white" : "bg-white/5 border-white/10 text-zinc-450 hover:text-white hover:bg-white/10"}`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Brand Filter */}
                  <div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 block mb-2.5">Brand</span>
                    <div className="grid grid-cols-2 gap-2">
                      {BRANDS.map(brand => (
                        <button
                          key={brand}
                          onClick={() => setSelectedBrand(selectedBrand === brand ? null : brand)}
                          className={`py-2 px-3 rounded-lg text-xs leading-none font-semibold border text-center transition-all cursor-pointer ${selectedBrand === brand ? "bg-blue-600 border-blue-600 text-white" : "bg-white/5 border-white/10 text-zinc-300 hover:text-white hover:bg-white/10"}`}
                        >
                          {brand}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Size Filter */}
                  <div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 block mb-2.5 font-semibold">Shoe Size (US Men)</span>
                    <div className="grid grid-cols-5 gap-2">
                      {ALL_SIZES.map(s => (
                        <button
                          key={s}
                          onClick={() => setSelectedSize(selectedSize === s ? null : s)}
                          className={`w-full h-10 rounded-lg text-xs font-bold font-mono flex items-center justify-center border transition-all cursor-pointer ${selectedSize === s ? "bg-blue-600 border-blue-600 text-white font-extrabold" : "bg-white/5 border-white/10 text-zinc-400 hover:text-white hover:bg-white/10"}`}
                        >
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Color Filter */}
                  <div>
                    <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 block mb-2.5">Color Palette</span>
                    <div className="flex flex-wrap gap-2">
                      {availableColors.map(col => (
                        <button
                          key={col.name}
                          onClick={() => setSelectedColor(selectedColor === col.name ? null : col.name)}
                          className={`flex items-center gap-2 py-1.5 px-3 rounded-full border text-xs cursor-pointer transition-all ${selectedColor === col.name ? "bg-white text-black border-white font-semibold" : "bg-white/5 border-white/10 text-zinc-400 hover:text-white"}`}
                        >
                          <span 
                            className="w-3.5 h-3.5 rounded-full border border-black/10 shadow-sm"
                            style={{ backgroundColor: col.hex }}
                          />
                          {col.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Price Filter */}
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500">Max Budget</span>
                      <span className="text-blue-400 font-mono text-xs font-bold">${maxPrice}</span>
                    </div>
                    <input
                      type="range"
                      min={100}
                      max={300}
                      step={5}
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(Number(e.target.value))}
                      className="w-full accent-blue-500 cursor-pointer h-1.5 bg-zinc-850 rounded-lg"
                    />
                    <div className="flex justify-between text-[11px] text-zinc-600 font-mono mt-1">
                      <span>$100</span>
                      <span>$300</span>
                    </div>
                  </div>

                </div>
              </div>

              {/* Apply/Reset action bar */}
              <div className="space-y-3 pt-6 border-t border-white/10">
                <div className="flex justify-between text-zinc-450 text-xs font-mono">
                  <span>Matches count:</span>
                  <span className="text-white font-bold">{processedShoes.length} models</span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={resetAllFilters}
                    className="flex-1 bg-white/5 border border-white/10 text-zinc-400 hover:text-white text-xs font-bold py-3 px-3 rounded-xl transition-all cursor-pointer text-center"
                  >
                    Clear All
                  </button>
                  <button
                    onClick={() => setIsFilterOpen(false)}
                    className="flex-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-bold py-3 px-4 rounded-xl shadow-lg hover:from-blue-500 hover:to-purple-500 transition-all cursor-pointer text-center"
                  >
                    Apply Filter & Refresh
                  </button>
                </div>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
