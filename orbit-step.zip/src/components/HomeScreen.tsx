import React, { useState } from "react";
import { motion } from "motion/react";
import { Search, ShoppingBag, User, ArrowRight, Star, Flame, Percent, Sparkles, LogOut, Heart } from "lucide-react";
import { Shoe } from "../types";
import { MOCK_SHOES, CATEGORIES } from "../data";

interface HomeScreenProps {
  onNavigate: (screen: string, params?: any) => void;
  cartCount: number;
  userEmail: string;
  onLogout: () => void;
  wishlist: string[];
  onToggleWishlist: (id: string) => void;
}

const HERO_BANNERS = [
  {
    id: "hero_1",
    title: "AIR-MAX HORIZON",
    subtitle: "Shatter your boundaries with cloud-grade responsiveness",
    discount: "NEW RELEASE",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?q=80&w=600&auto=format&fit=crop",
    shoeId: "shoe_1",
    bgColor: "from-rose-950 to-zinc-950"
  },
  {
    id: "hero_2",
    title: "VINTAGE RETRO RUNNER",
    subtitle: "High-top canvas with retro court-side character",
    discount: "20% EXCLUSIVE",
    image: "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=600&auto=format&fit=crop",
    shoeId: "shoe_3",
    bgColor: "from-violet-950 to-zinc-950"
  },
  {
    id: "hero_3",
    title: "ITALIAN BROGUE CLASSIC",
    subtitle: "Florence craftsmanship with genuine box-calf finish",
    discount: "HERITAGE COUT",
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=600&auto=format&fit=crop",
    shoeId: "shoe_5",
    bgColor: "from-amber-950 to-zinc-950"
  }
];

export default function HomeScreen({ 
  onNavigate, 
  cartCount, 
  userEmail, 
  onLogout,
  wishlist,
  onToggleWishlist
}: HomeScreenProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeBannerIdx, setActiveBannerIdx] = useState(0);
  const [profileOpen, setProfileOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate("PLP", { query: searchQuery.trim() });
    }
  };

  const activeBanner = HERO_BANNERS[activeBannerIdx];
  const trendingShoes = MOCK_SHOES.filter(s => s.trending);

  return (
    <div id="home-screen-wrapper" className="space-y-6">
      
      {/* 1. TOP BAR with profile icon, search, and cart */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-blue-400 text-xs font-mono tracking-[0.2em] block">EDITION 2026</span>
          <h1 className="font-display text-2xl font-black text-white italic tracking-tight flex items-center gap-1 uppercase">
            Kicks<span className="text-blue-400">Premium</span>
          </h1>
        </div>

        {/* Search bar & profile controls */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          <form onSubmit={handleSearchSubmit} className="relative flex-1 md:w-64">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search sneakers, boots, brands..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white/5 backdrop-blur-md text-sm text-white pl-10 pr-4 py-2.5 rounded-xl border border-white/10 focus:outline-none focus:border-blue-500/85 transition-all placeholder-zinc-500"
            />
          </form>

          {/* Cart Icon */}
          <button
            id="home-cart-btn"
            onClick={() => onNavigate("CART")}
            className="p-2.5 rounded-xl bg-white/5 backdrop-blur-md border border-white/10 text-zinc-300 hover:text-blue-400 hover:border-blue-500/30 transition-all relative cursor-pointer"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 flex items-center justify-center bg-blue-600 text-white text-[10px] font-bold rounded-full border-2 border-slate-950 animate-pulse">
                {cartCount}
              </span>
            )}
          </button>

          {/* Profile Dropdown */}
          <div className="relative">
            <button
              id="home-profile-btn"
              onClick={() => setProfileOpen(!profileOpen)}
              className="p-2.5 rounded-xl bg-white/5 backdrop-blur-md border border-white/10 text-zinc-300 hover:text-blue-400 hover:border-blue-500/30 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <User className="w-5 h-5" />
            </button>

            {profileOpen && (
              <div 
                id="profile-dropdown-card"
                className="absolute right-0 mt-2 w-60 glass-panel rounded-xl shadow-2xl p-4 z-40 space-y-3"
              >
                <div>
                  <span className="text-zinc-500 text-[10px] uppercase font-mono block">Signed in as</span>
                  <span className="text-white text-xs font-semibold truncate block">{userEmail}</span>
                </div>
                <div className="h-[1px] bg-zinc-800" />
                <button
                  id="profile-fav-btn"
                  onClick={() => {
                    setProfileOpen(false);
                    onNavigate("PLP", { wishlistOnly: true });
                  }}
                  className="w-full text-left text-xs text-zinc-300 hover:text-white flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <Heart className="w-4 h-4 text-rose-500" />
                  My Wishlist ({wishlist.length})
                </button>
                <button
                  id="profile-orders-btn"
                  onClick={() => {
                    setProfileOpen(false);
                    onNavigate("ORDERS");
                  }}
                  className="w-full text-left text-xs text-zinc-300 hover:text-white flex items-center gap-2 transition-colors cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4 text-emerald-500" />
                  Active Orders
                </button>
                <div className="h-[1px] bg-zinc-800" />
                <button
                  id="profile-logout-btn"
                  onClick={() => {
                    setProfileOpen(false);
                    onLogout();
                  }}
                  className="w-full text-left text-xs text-rose-400 hover:text-rose-300 flex items-center gap-2 transition-colors font-semibold cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 2. INTERACTIVE HORIZONTAL SCROLLING BANNER */}
      <div 
        id="hero-banner-container"
        className="relative overflow-hidden rounded-[2rem] bg-gradient-to-r from-blue-900/30 to-purple-950/20 border border-white/10 p-6 md:p-8 flex flex-col md:flex-row items-center gap-6 transition-all duration-700 backdrop-blur-xl"
      >
        <div className="absolute top-3 right-3 flex items-center gap-1.5 bg-blue-500/10 px-2.5 py-1 rounded-full border border-blue-500/20 text-blue-400 text-[10px] font-mono">
          <Percent className="w-3 h-3" />
          NEW DROP
        </div>

        <div className="flex-1 space-y-4">
          <span className="inline-block bg-white/10 text-white text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full font-mono">
            {activeBanner.discount}
          </span>
          <h2 className="font-display text-2xl md:text-3xl font-black italic text-white tracking-tight leading-none uppercase">
            {activeBanner.title}
          </h2>
          <p className="text-zinc-400 text-xs md:text-sm max-w-md font-sans leading-relaxed">
            {activeBanner.subtitle}
          </p>
          <button
            id={`btn-banner-action-${activeBanner.id}`}
            onClick={() => onNavigate("PDP", { shoeId: activeBanner.shoeId })}
            className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white font-display font-medium text-xs py-2.5 px-5 rounded-2xl transition-all cursor-pointer shadow-lg shadow-blue-500/20"
          >
            Explore Collection <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="w-48 h-36 md:w-64 md:h-44 relative flex items-center justify-center">
          <motion.img
            key={activeBanner.id}
            initial={{ opacity: 0, scale: 0.8, rotate: -15, y: 15 }}
            animate={{ opacity: 1, scale: 1, rotate: -10, y: 0 }}
            transition={{ type: "spring", stiffness: 100 }}
            src={activeBanner.image}
            alt={activeBanner.title}
            className="w-full h-full object-contain filter drop-shadow-[0_15px_15px_rgba(239,68,68,0.3)] pointer-events-none"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Carousel indicators */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 md:left-8 md:translate-x-0 flex gap-1.5 z-20">
          {HERO_BANNERS.map((_, index) => (
            <button
              key={index}
              onClick={() => setActiveBannerIdx(index)}
              className={`h-1.5 rounded-full transition-all cursor-pointer ${index === activeBannerIdx ? "w-6 bg-blue-500" : "w-1.5 bg-white/20 hover:bg-zinc-500"}`}
              title={`View slide ${index + 1}`}
            />
          ))}
        </div>
      </div>

      {/* 3. GRID LAYOUT FOR CATEGORIES */}
      <div id="categories-section">
        <h3 className="font-display text-sm font-bold uppercase tracking-widest text-zinc-500 mb-3 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-blue-400" />
          Select Category
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {CATEGORIES.map((cat) => {
            const getCatMeta = (c: string) => {
              switch (c) {
                case "Sneakers":
                  return { gradient: "from-purple-950 to-zinc-900 border-purple-500/15", text: "text-purple-400" };
                case "Sports":
                  return { gradient: "from-rose-950 to-zinc-900 border-rose-500/15", text: "text-rose-400" };
                case "Casual":
                  return { gradient: "from-amber-950 to-zinc-900 border-amber-500/15", text: "text-amber-400" };
                case "Formal":
                default:
                  return { gradient: "from-emerald-950 to-zinc-900 border-emerald-500/15", text: "text-emerald-400" };
              }
            };
            const meta = getCatMeta(cat);
            return (
              <button
                key={cat}
                onClick={() => onNavigate("PLP", { category: cat })}
                className={`relative overflow-hidden rounded-xl bg-gradient-to-b ${meta.gradient} border p-4 hover:scale-[1.02] active:scale-[0.98] transition-all text-left cursor-pointer group`}
              >
                <span className="text-zinc-500 text-[10px] font-mono tracking-wider block">COLLECTION</span>
                <span className="font-display text-lg font-bold text-white tracking-tight leading-tight block group-hover:translate-x-1 transition-transform">
                  {cat}
                </span>
                <span className={`text-[10px] font-mono font-semibold ${meta.text} mt-2 inline-flex items-center gap-0.5 group-hover:underline`}>
                  Browse All <ArrowRight className="w-3 h-3" />
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4. "TRENDING NOW" SECTION */}
      <div id="trending-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-display text-sm font-bold uppercase tracking-widest text-zinc-500 flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-blue-400" />
            Trending Releases
          </h3>
          <button
            onClick={() => onNavigate("PLP")}
            className="text-xs text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1 transition-colors hover:underline"
          >
            See All <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {trendingShoes.map((shoe) => {
            const isWishlisted = wishlist.includes(shoe.id);
            return (
              <div
                key={shoe.id}
                className="group relative rounded-3xl glass-panel p-4 flex flex-col justify-between hover:border-white/20 transition-all duration-300 overflow-hidden"
              >
                {/* Wishlist Heart */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleWishlist(shoe.id);
                  }}
                  className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-400 hover:text-blue-400 z-10 transition-colors cursor-pointer"
                  title="Toggle wishlist"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? "fill-blue-500 text-blue-500" : ""}`} />
                </button>

                {/* Top Badge */}
                {shoe.originalPrice && (
                  <span className="absolute top-3 left-3 bg-blue-500/20 text-blue-400 text-[10px] font-bold px-2 py-0.5 rounded border border-blue-500/20 font-mono z-10">
                    SALE
                  </span>
                )}

                {/* Main Card Trigger */}
                <div 
                  onClick={() => onNavigate("PDP", { shoeId: shoe.id })}
                  className="cursor-pointer space-y-3"
                >
                  {/* Photo area */}
                  <div className="w-full h-36 relative bg-zinc-950 rounded-xl overflow-hidden flex items-center justify-center p-3">
                    <img
                      src={shoe.images[0]}
                      alt={shoe.name}
                      className="max-h-full max-w-full object-contain -rotate-6 group-hover:-rotate-12 group-hover:scale-105 transition-all duration-300"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Brand & Stars */}
                  <div className="flex justify-between items-center text-[11px]">
                    <span className="text-blue-400 font-semibold tracking-wider font-mono uppercase">{shoe.brand}</span>
                    <span className="text-zinc-400 flex items-center gap-0.5 font-mono">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {shoe.rating}
                    </span>
                  </div>

                  {/* Shoe title */}
                  <h4 className="font-display text-md font-bold text-white tracking-tight truncate leading-snug">
                    {shoe.name}
                  </h4>
                </div>

                {/* Price and Add button bar */}
                <div className="flex items-center justify-between border-t border-white/5 mt-3 pt-3">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-blue-400 font-display font-extrabold text-lg">${shoe.price}</span>
                    {shoe.originalPrice && (
                      <span className="text-zinc-500 line-through text-xs font-mono">${shoe.originalPrice}</span>
                    )}
                  </div>

                  <button
                    id={`btn-view-shoe-${shoe.id}`}
                    onClick={() => onNavigate("PDP", { shoeId: shoe.id })}
                    className="bg-white/5 hover:bg-blue-600 text-zinc-300 hover:text-white text-xs font-bold py-2 px-3.5 rounded-xl border border-white/10 hover:border-transparent transition-all flex items-center gap-1 cursor-pointer"
                  >
                    Details <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
    </div>
  );
}
