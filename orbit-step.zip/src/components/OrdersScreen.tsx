import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Package, Clock, ShieldCheck, MapPin, CheckCircle2, ChevronRight, Ban, RefreshCw, X, Play } from "lucide-react";
import { Order, OrderStep } from "../types";

interface OrdersScreenProps {
  onNavigate: (screen: string, params?: any) => void;
  orders: Order[];
  onCancelOrder: (orderId: string) => void;
  onUpdateStep: (orderId: string, newStep: OrderStep) => void;
}

export default function OrdersScreen({ 
  onNavigate, 
  orders, 
  onCancelOrder,
  onUpdateStep
}: OrdersScreenProps) {
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(
    orders.length > 0 ? orders[0].id : null
  );

  // Modal dialog triggers
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showReturnModal, setShowReturnModal] = useState(false);
  const [actionReason, setActionReason] = useState("");
  const [modalFeedback, setModalFeedback] = useState("");

  const activeOrder = orders.find(o => o.id === selectedOrderId);

  const steps = [
    { label: "Ordered", desc: "Order received in warehouse" },
    { label: "Packed", desc: "Packed & inspected by robotic arms" },
    { label: "Shipped", desc: "Assigned priority air transport" },
    { label: "Out for Delivery", desc: "Out via eco-electric sprinter" },
    { label: "Delivered", desc: "Securely left on doorstep / handoff" }
  ];

  const handleCancelSubmit = () => {
    if (!activeOrder) return;
    setModalFeedback("Cancelling your delivery...");
    setTimeout(() => {
      onCancelOrder(activeOrder.id);
      setModalFeedback("");
      setShowCancelModal(false);
      setActionReason("");
      setSelectedOrderId(orders.length > 1 ? orders.filter(o => o.id !== activeOrder.id)[0].id : null);
    }, 1500);
  };

  const handleReturnSubmit = () => {
    if (!activeOrder) return;
    setModalFeedback("Filing substitution request...");
    setTimeout(() => {
      setModalFeedback("");
      setShowReturnModal(false);
      setActionReason("");
      alert("Return & replacement ticket filed successfully! Check your email for shipping label instructions.");
    }, 1800);
  };

  // Helper to speed through step simulation
  const simulateNextStep = () => {
    if (!activeOrder) return;
    const current = activeOrder.step;
    if (current < OrderStep.DELIVERED) {
      onUpdateStep(activeOrder.id, (current + 1) as OrderStep);
    } else {
      onUpdateStep(activeOrder.id, OrderStep.ORDERED); // wrap around
    }
  };

  return (
    <div id="orders-screen-wrapper" className="space-y-6 min-h-[70vh] pb-10">
      
      {/* HEADER SECTION */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <button
            id="btn-orders-back"
            onClick={() => onNavigate("HOME")}
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-display text-xl font-bold text-white tracking-tight">
              Order Tracking
            </h1>
            <span className="text-zinc-500 text-xs font-mono">
              Live status & history ({orders.length} orders total)
            </span>
          </div>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600">
            <Package className="w-8 h-8 text-neutral-600" />
          </div>
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white">No Active Orders Yet</h3>
            <p className="text-zinc-500 text-xs max-w-xs">
              Go to the shopping cart, add some sneakers and complete checkout to begin tracking real items in real-time.
            </p>
          </div>
          <button
            onClick={() => onNavigate("PLP")}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-xs font-bold py-2.5 px-6 rounded-xl transition-all shadow-lg shadow-blue-500/10 font-display uppercase tracking-wider cursor-pointer"
          >
            Start Shopping
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* ORDERS DIRECTORY BOX */}
          <div className="space-y-3 lg:col-span-1">
            <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 font-bold block">Items List</span>
            
            <div className="space-y-2 max-h-[400px] overflow-y-auto no-scrollbar">
              {orders.map((o) => {
                const isActive = o.id === selectedOrderId;
                const itemsStr = o.items.map(i => `${i.quantity}x ${i.shoe.name}`).join(", ");
                return (
                  <button
                    key={o.id}
                    onClick={() => setSelectedOrderId(o.id)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${isActive ? "bg-blue-600/20 border-blue-500/50 text-white shadow-lg backdrop-blur-md" : "bg-white/5 border-white/10 hover:bg-white/10 text-zinc-350 hover:text-white"}`}
                  >
                    <div className="space-y-1 pr-2 truncate">
                      <div className="flex items-center gap-2">
                        <span className="text-zinc-500 text-[10px] font-mono">ID: {o.id.toUpperCase()}</span>
                        <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${o.step === OrderStep.DELIVERED ? "bg-emerald-500/15 border border-emerald-500/25 text-emerald-400" : "bg-blue-500/15 border border-blue-500/25 text-blue-400"}`}>
                          {steps[o.step].label}
                        </span>
                      </div>
                      <p className="font-sans text-xs font-bold truncate text-white">{itemsStr}</p>
                      <span className="text-[10px] text-zinc-500 block font-mono">Placed on {o.date}</span>
                    </div>
                    <ChevronRight className={`w-4 h-4 shrink-0 transition-transform ${isActive ? "text-blue-500 uppercase translate-x-0.5" : "text-zinc-600"}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* ACTIVE DISPATCH PANEL AND STEPPER TRACKER */}
          {activeOrder ? (
            <div className="lg:col-span-2 space-y-5 glass-panel p-5 rounded-2xl">
              
              {/* Stepper tracking header */}
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-3 pb-4 border-b border-white/5">
                <div>
                  <span className="text-zinc-500 text-[10px] font-mono">TRACKING CODE: {activeOrder.id.toUpperCase()}</span>
                  <div className="flex items-baseline gap-2 mt-0.5">
                    <h2 className="font-display text-lg font-bold text-white uppercase italic">DISPATCH STATUS</h2>
                    <span className="text-blue-400 text-xs font-mono font-bold">● LIVE UPDATE</span>
                  </div>
                </div>

                {/* Simulation button */}
                <button
                  id="btn-simulate-step"
                  onClick={simulateNextStep}
                  className="flex items-center gap-2 bg-[#020617]/50 border border-white/10 text-[10px] font-mono hover:text-blue-300 hover:border-blue-550/40 font-bold px-3 py-1.5 rounded-lg text-blue-400 cursor-pointer self-start transition-all"
                  title="Simulate shipping progression for local test"
                >
                  <Play className="w-3 h-3 text-blue-500" />
                  Simulate Next Step
                </button>
              </div>

              {/* TIMELINE METADATA CARD */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-[#020617]/40 p-3.5 rounded-xl border border-white/10 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                    <Clock className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-550 uppercase font-semibold">Scheduled Arrival</span>
                    <p className="text-white text-xs font-bold font-mono">{activeOrder.expectedDelivery}</p>
                  </div>
                </div>

                <div className="bg-[#020617]/40 p-3.5 rounded-xl border border-white/10 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                    <ShieldCheck className="w-5 h-5 text-purple-400" />
                  </div>
                  <div>
                    <span className="text-[10px] text-zinc-550 uppercase font-semibold">Shipping Mode</span>
                    <p className="text-white text-xs font-bold">Orbit Step Free Express Shipping</p>
                  </div>
                </div>
              </div>

              {/* VISUAL STEPPER TRACKING BAR */}
              <div id="visual-timeline-stepper" className="space-y-4 pt-4">
                <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-550 font-semibold block">Delivery Route Chronology</span>
                
                <div className="relative pl-7 space-y-6">
                  {/* Vertical background connector line */}
                  <div className="absolute left-[9px] top-3.5 bottom-3.5 w-0.5 bg-white/5" />

                  {/* Active background line */}
                  <div 
                    className="absolute left-[9px] top-3.5 w-0.5 bg-gradient-to-b from-blue-500 to-purple-500 transition-all duration-500"
                    style={{
                      height: `${(activeOrder.step / (steps.length - 1)) * 92}%`
                    }}
                  />

                  {steps.map((st, sIdx) => {
                    const isDone = sIdx < activeOrder.step;
                    const isCurrent = sIdx === activeOrder.step;
                    return (
                      <div key={sIdx} className="relative flex items-start gap-4">
                        
                        {/* Circle bullet node */}
                        <div className="absolute -left-[24px] top-1 z-10">
                          {isDone ? (
                            <div className="w-5 h-5 bg-emerald-580/10 rounded-full border-2 border-emerald-500 flex items-center justify-center">
                              <CheckCircle2 className="w-3 h-3 text-emerald-400 fill-zinc-950" />
                            </div>
                          ) : isCurrent ? (
                            <div className="w-5 h-5 bg-blue-500 rounded-full border-2 border-zinc-900 flex items-center justify-center relative">
                              <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping absolute" />
                              <span className="w-1.5 h-1.5 bg-white rounded-full bg-blue-200" />
                            </div>
                          ) : (
                            <div className="w-5 h-5 bg-white/5 border border-white/20 rounded-full" />
                          )}
                        </div>

                        {/* Node Label */}
                        <div className="space-y-0.5">
                          <h4 className={`font-display text-xs font-extrabold tracking-tight ${isCurrent ? "text-blue-400" : isDone ? "text-zinc-300" : "text-zinc-650"}`}>
                            {st.label.toUpperCase()}
                          </h4>
                          <p className={`text-[10px] font-sans ${isCurrent ? "text-zinc-300 font-medium" : "text-zinc-550"}`}>{st.desc}</p>
                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>

              {/* DELIVERY ADDRESS SUMMARY */}
              <div className="pt-4 border-t border-white/5 space-y-2">
                <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-550 block">Dispatch Consignee Info</span>
                <div className="bg-[#020617]/40 p-4 rounded-xl border border-white/10 flex items-start gap-3">
                  <MapPin className="w-4.5 h-4.5 text-zinc-550 shrink-0 mt-0.5" />
                  <div className="space-y-1 font-sans text-xs">
                    <p className="text-white font-bold">{activeOrder.address.fullName}</p>
                    <p className="text-zinc-400">{activeOrder.address.addressLine}, {activeOrder.address.city}, {activeOrder.address.zipCode}</p>
                    <p className="text-zinc-500 block font-mono">Mobile: {activeOrder.address.phoneNumber}</p>
                  </div>
                </div>
              </div>

              {/* ACTION BUTTONS (CANCEL / RETURN) */}
              <div className="flex gap-2 pt-2">
                {activeOrder.step < OrderStep.SHIPPED ? (
                  <button
                    id="btn-trigger-cancel"
                    onClick={() => setShowCancelModal(true)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 hover:border-rose-500/40 text-rose-400 text-xs font-semibold py-3 rounded-xl transition-all cursor-pointer"
                  >
                    <Ban className="w-4 h-4" />
                    Cancel Order
                  </button>
                ) : (
                  <button
                    id="btn-trigger-return"
                    onClick={() => setShowReturnModal(true)}
                    className="flex-1 flex items-center justify-center gap-1.5 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-zinc-300 text-xs font-semibold py-3 rounded-xl transition-all cursor-pointer"
                  >
                    <RefreshCw className="w-4 h-4 text-amber-500" />
                    Return / Exchange
                  </button>
                )}
              </div>

            </div>
          ) : (
            <div className="lg:col-span-2 text-center text-zinc-500 text-xs py-10">
              Select an item on the left to review shipping telemetry routes.
            </div>
          )}

        </div>
      )}

      {/* MODAL DIALOGS */}
      {/* 1. Cancellation Modal */}
      <AnimatePresence>
        {showCancelModal && activeOrder && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm glass-panel p-6 rounded-2xl relative space-y-4"
            >
              <button 
                onClick={() => setShowCancelModal(false)}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="space-y-1">
                <h3 className="font-display text-lg font-bold text-white uppercase italic">Confirm Cancellation</h3>
                <p className="text-zinc-400 text-[11px]">
                  Cancellation is only allowed during pre-shipment steps. Refund will be credited immediately to your digital wallet.
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono text-zinc-500">Reason for Cancellation</span>
                <textarea
                  placeholder="e.g. Ordered a wrong shoe size, found a different deal, etc..."
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  className="w-full h-20 bg-[#020617]/50 text-xs text-white p-3 border border-white/10 rounded-xl focus:outline-none focus:border-blue-500/80 transition-all"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowCancelModal(false)}
                  className="flex-1 bg-white/5 border border-white/10 text-zinc-300 text-xs font-semibold py-2.5 rounded-xl cursor-pointer hover:bg-white/10 transition-colors animate-fade"
                >
                  Dismiss
                </button>
                <button
                  onClick={handleCancelSubmit}
                  disabled={!actionReason.trim() || !!modalFeedback}
                  className="flex-1 bg-blue-600 text-white text-xs font-semibold py-2.5 rounded-xl cursor-pointer hover:bg-blue-550 transition-colors disabled:opacity-50 flex items-center justify-center shadow-lg shadow-blue-500/10"
                >
                  {modalFeedback || "Confirm Cancel"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 2. Return Modal */}
      <AnimatePresence>
        {showReturnModal && activeOrder && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm glass-panel p-6 rounded-2xl relative space-y-4"
            >
              <button 
                onClick={() => setShowReturnModal(false)}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>

              <div className="space-y-1">
                <h3 className="font-display text-lg font-bold text-white uppercase italic">Return or Exchange</h3>
                <p className="text-zinc-400 text-[11px]">
                  Filing an exchange request requires returning the original un-scuffed footwear within 30 days of arrival.
                </p>
              </div>

              <div className="space-y-2">
                <span className="text-[10px] uppercase font-mono text-zinc-500">Reason for Request</span>
                <select
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  className="w-full bg-[#020617]/50 border border-white/10 text-zinc-300 text-xs p-3 rounded-xl focus:outline-none focus:border-blue-500/80 transition-all"
                >
                  <option value="">Select a reason...</option>
                  <option value="size">Size does not fit productively</option>
                  <option value="color">Not in agreement with real colors</option>
                  <option value="damaged">Defect in product stitching</option>
                  <option value="mind">Change of mind</option>
                </select>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setShowReturnModal(false)}
                  className="flex-1 bg-white/5 border border-white/10 text-zinc-300 text-xs font-semibold py-2.5 rounded-xl cursor-pointer hover:bg-white/10 transition-colors"
                >
                  Dismiss
                </button>
                <button
                  onClick={handleReturnSubmit}
                  disabled={!actionReason || !!modalFeedback}
                  className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 text-white text-xs font-semibold py-2.5 rounded-xl cursor-pointer hover:scale-[1.01] transition-all disabled:opacity-50 flex items-center justify-center"
                >
                  {modalFeedback || "File Exchange Ticket"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
