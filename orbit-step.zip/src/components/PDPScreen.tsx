import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Star, Heart, ShoppingBag, ChevronDown, ChevronUp, Plus, Minus, CheckCircle, HelpCircle } from "lucide-react";
import { Shoe } from "../types";
import { MOCK_SHOES } from "../data";

interface PDPScreenProps {
  shoeId: string;
  onNavigate: (screen: string, params?: any) => void;
  onAddToCart: (shoe: Shoe, selectedSize: number, selectedColor: string, quantity: number) => void;
  wishlist: string[];
  onToggleWishlist: (id: string) => void;
}

export default function PDPScreen({ 
  shoeId, 
  onNavigate, 
  onAddToCart,
  wishlist,
  onToggleWishlist
}: PDPScreenProps) {
  // Find selected shoe or fall back to first mock shoe
  const shoe = MOCK_SHOES.find((s) => s.id === shoeId) || MOCK_SHOES[0];

  // Carousel State
  const [activeImgIdx, setActiveImgIdx] = useState(0);

  // Custom Choices States
  const [selectedSize, setSelectedSize] = useState<number>(shoe.sizes[0] || 9);
  const [selectedColor, setSelectedColor] = useState<string>(shoe.colors[0]?.name || "Crimson Red");
  const [quantity, setQuantity] = useState<number>(1);

  // Accordion drawer status
  const [openSection, setOpenSection] = useState<string | null>("material");

  // Success Confirmation Popup State
  const [showCartSuccess, setShowCartSuccess] = useState(false);

  const selectedColorHex = shoe.colors.find(c => c.name === selectedColor)?.hex || "#FFFFFF";
  const isWishlisted = wishlist.includes(shoe.id);

  const handleAddToCart = () => {
    onAddToCart(shoe, selectedSize, selectedColor, quantity);
    setShowCartSuccess(true);
    setTimeout(() => {
      setShowCartSuccess(false);
    }, 2500);
  };

  const handleBuyNow = () => {
    onAddToCart(shoe, selectedSize, selectedColor, quantity);
    onNavigate("CART");
  };

  const toggleSection = (section: string) => {
    setOpenSection(openSection === section ? null : section);
  };

  return (
    <div id="pdp-screen-wrapper" className="space-y-6 pb-28 relative">
      
      {/* HEADER CONTROLS */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <button
          id="btn-pdp-back"
          onClick={() => onNavigate("PLP")}
          className="p-2 rounded-xl bg-white/5 border border-white/10 text-zinc-350 hover:text-white transition-all cursor-pointer flex items-center gap-1.5 hover:bg-white/10"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-xs font-semibold">Back to Catalog</span>
        </button>

        <div className="flex items-center gap-2">
          {/* Wishlist */}
          <button
            onClick={() => onToggleWishlist(shoe.id)}
            className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 hover:text-blue-500 transition-colors cursor-pointer"
            title="Toggle wishlist"
          >
            <Heart className={`w-4 h-4 ${isWishlisted ? "fill-blue-550 text-blue-500" : ""}`} />
          </button>

          {/* Cart page shortcut */}
          <button
            onClick={() => onNavigate("CART")}
            className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-zinc-300 hover:text-blue-400 transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* DYNAMIC CONFIRMATION TOAST */}
      <AnimatePresence>
        {showCartSuccess && (
          <motion.div
            id="cart-success-toast"
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 w-full max-w-xs p-4 glass-panel bg-zinc-950/95 border border-emerald-500/30 text-white rounded-xl shadow-2xl flex items-center gap-3"
          >
            <CheckCircle className="w-6 h-6 text-emerald-400 shrink-0" />
            <div>
              <p className="text-xs font-bold text-emerald-400">Added to Shopping Cart!</p>
              <p className="text-[10px] text-zinc-400 truncate">
                {quantity}x {shoe.name} (Size {selectedSize})
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* TWO COLUMN / HERO SECTION FOR DISPLAY */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        
        {/* CAROUSEL PANEL */}
        <div className="space-y-3">
          <div className="w-full h-64 md:h-80 relative bg-[#020617]/40 rounded-2xl overflow-hidden flex items-center justify-center p-6 border border-white/10 shadow-inner">
            <span className="absolute top-3 left-3 bg-white/10 backdrop-blur-md px-2.5 py-1 rounded-full border border-white/10 text-[10px] font-mono text-blue-400">
              {shoe.category.toUpperCase()}
            </span>

            <motion.img
              key={activeImgIdx}
              initial={{ opacity: 0, scale: 0.9, rotate: -4 }}
              animate={{ opacity: 1, scale: 1, rotate: -8 }}
              transition={{ duration: 0.4 }}
              src={shoe.images[activeImgIdx]}
              alt={`${shoe.name} View ${activeImgIdx + 1}`}
              className="max-h-full max-w-full object-contain filter drop-shadow-[0_15px_15px_rgba(255,255,255,0.05)] select-none pointer-events-none"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Multiple Angle Thumbnails */}
          <div className="flex gap-2">
            {shoe.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImgIdx(idx)}
                className={`flex-1 h-16 bg-[#020617]/45 rounded-xl overflow-hidden flex items-center justify-center p-2 border transition-all cursor-pointer ${idx === activeImgIdx ? "border-blue-500 ring-2 ring-blue-500/20" : "border-white/10 hover:border-white/20"}`}
              >
                <img 
                  src={img} 
                  alt="Thumbnail view" 
                  className="max-h-full max-w-full object-contain -rotate-6"
                  referrerPolicy="no-referrer"
                />
              </button>
            ))}
          </div>
        </div>

        {/* SPECIFICATIONS & INTERACTION PANEL */}
        <div className="space-y-5">
          <div>
            <span className="text-zinc-500 text-xs font-mono tracking-wider font-semibold uppercase">{shoe.brand}</span>
            <h2 className="font-display text-2xl md:text-3xl font-black italic tracking-tight text-white uppercase mt-0.5">
              {shoe.name}
            </h2>

            {/* Ratings & reviews count */}
            <div className="flex items-center gap-3 mt-1.5 text-xs text-zinc-450">
              <span className="flex items-center gap-0.5 font-mono text-amber-400 font-bold bg-[#020617]/30 px-2 py-1 rounded border border-white/10">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                {shoe.rating}
              </span>
              <span className="underline font-sans">{shoe.reviewsCount} customer reviews</span>
            </div>
          </div>

          {/* Price Tag */}
          <div className="flex items-baseline gap-2 bg-gradient-to-r from-blue-950/20 to-transparent p-3 rounded-xl border border-white/10">
            <span className="text-zinc-550 text-xs font-mono">Retail Price:</span>
            <span className="text-blue-400 font-display font-extrabold text-2xl">${shoe.price}</span>
            {shoe.originalPrice && (
              <span className="text-zinc-500 line-through text-sm font-mono font-medium">${shoe.originalPrice}</span>
            )}
          </div>

          {/* Description summary */}
          <p className="text-zinc-400 text-xs md:text-sm font-sans leading-relaxed">
            {shoe.description}
          </p>

          {/* DYNAMIC COLOR SELECTION */}
          <div>
            <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 block mb-2.5 font-bold">Selected Colorway: <span className="text-white normal-case">{selectedColor}</span></span>
            <div className="flex gap-3">
              {shoe.colors.map((color) => (
                <button
                  key={color.name}
                  onClick={() => setSelectedColor(color.name)}
                  className={`w-8 h-8 rounded-full border-2 transition-all flex items-center justify-center cursor-pointer ${selectedColor === color.name ? "border-blue-500 scale-110" : "border-white/10 hover:border-white/30"}`}
                  title={color.name}
                >
                  <span 
                    className="w-5.5 h-5.5 rounded-full block border border-black/10 shadow shadow-inner"
                    style={{ backgroundColor: color.hex }}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* INTERACTIVE SHOE SIZE SELECTOR */}
          <div>
            <div className="flex justify-between items-center mb-2.5">
              <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 font-bold">Available Sizes (US Men's)</span>
              <span className="text-blue-400 text-[10px] uppercase font-semibold">Standard Fit guidelines</span>
            </div>
            
            <div className="grid grid-cols-5 gap-2">
              {shoe.sizes.map((sz) => (
                <button
                  key={sz}
                  onClick={() => setSelectedSize(sz)}
                  className={`py-3.5 rounded-lg text-xs font-bold font-mono border transition-all cursor-pointer ${selectedSize === sz ? "bg-blue-600 border-blue-600 text-white font-black shadow-lg shadow-blue-500/20" : "bg-white/5 border border-white/10 text-zinc-405 hover:text-zinc-200 hover:bg-white/10"}`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity Picker */}
          <div className="flex items-center gap-4">
            <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-550 font-semibold mb-0.5">Quantity:</span>
            <div className="flex items-center bg-white/5 border border-white/10 rounded-lg p-1">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1 px-2.5 rounded bg-[#020617]/50 text-zinc-400 hover:text-white hover:bg-white/10 transition-all disabled:opacity-50"
                disabled={quantity === 1}
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="w-10 text-center font-mono text-sm text-white font-bold">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="p-1 px-2.5 rounded bg-[#020617]/50 text-zinc-400 hover:text-white hover:bg-white/10 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* DETAILED DESCRIPTION ACCORDION */}
          <div id="pdp-details-accordion" className="space-y-2 pt-2 border-t border-white/10">
            
            {/* 1. Material */}
            <div className="border border-white/10 rounded-xl overflow-hidden bg-white/5 backdrop-blur-md">
              <button
                onClick={() => toggleSection("material")}
                className="w-full flex items-center justify-between p-3.5 text-xs text-left font-semibold text-zinc-300 hover:text-white transition-colors cursor-pointer"
              >
                <span>Material & Construction Details</span>
                {openSection === "material" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <AnimatePresence>
                {openSection === "material" && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-white/10"
                  >
                    <p className="p-3.5 text-[11px] text-zinc-400 leading-relaxed font-sans bg-[#020617]/40">
                      {shoe.details.material}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 2. Care */}
            <div className="border border-white/10 rounded-xl overflow-hidden bg-white/5 backdrop-blur-md">
              <button
                onClick={() => toggleSection("care")}
                className="w-full flex items-center justify-between p-3.5 text-xs text-left font-semibold text-zinc-300 hover:text-white transition-colors cursor-pointer"
              >
                <span>Care Instructions</span>
                {openSection === "care" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <AnimatePresence>
                {openSection === "care" && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-white/10"
                  >
                    <p className="p-3.5 text-[11px] text-zinc-400 leading-relaxed font-sans bg-[#020617]/40">
                      {shoe.details.care}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* 3. Returns */}
            <div className="border border-white/10 rounded-xl overflow-hidden bg-white/5 backdrop-blur-md">
              <button
                onClick={() => toggleSection("returns")}
                className="w-full flex items-center justify-between p-3.5 text-xs text-left font-semibold text-zinc-300 hover:text-white transition-colors cursor-pointer"
              >
                <span>Hassle-Free Return Policy</span>
                {openSection === "returns" ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <AnimatePresence>
                {openSection === "returns" && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden border-t border-white/10"
                  >
                    <p className="p-3.5 text-[11px] text-zinc-400 leading-relaxed font-sans bg-[#020617]/40">
                      {shoe.details.returns}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

          </div>

        </div>

      </div>

      {/* FLOATING BOTTOM BAR WITH ADD TO CART AND BUY NOW */}
      <div 
        id="pdp-floating-bar-controls"
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 w-[95%] max-w-sm bg-slate-900/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-4 flex gap-3 shadow-2xl animate-in"
      >
        <button
          id="btn-pdp-add-cart"
          onClick={handleAddToCart}
          className="flex-1 text-center bg-white/5 border border-white/10 text-[#60a5fa] hover:text-white hover:bg-white/10 py-3.5 rounded-xl font-bold font-display text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer"
        >
          <ShoppingBag className="w-4 h-4 text-blue-500 animate-pulse" />
          Add to Cart
        </button>
        <button
          id="btn-pdp-buy-now"
          onClick={handleBuyNow}
          className="flex-1 text-center bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white py-3.5 rounded-xl font-bold font-display text-xs transition-all shadow-lg shadow-blue-500/20 cursor-pointer"
        >
          Buy Now
        </button>
      </div>

    </div>
  );
}
