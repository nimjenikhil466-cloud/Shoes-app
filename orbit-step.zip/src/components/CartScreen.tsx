import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Trash2, ArrowLeft, ShoppingBag, MapPin, CreditCard, ChevronRight, CheckCircle, Tag, Plus, Minus } from "lucide-react";
import { CartItem } from "../types";

interface CartScreenProps {
  onNavigate: (screen: string, params?: any) => void;
  cartItems: CartItem[];
  onRemoveItem: (id: string) => void;
  onUpdateCartQuantity: (id: string, qty: number) => void;
  onCheckout: (address: {
    fullName: string;
    phoneNumber: string;
    addressLine: string;
    city: string;
    zipCode: string;
  }) => void;
}

export default function CartScreen({
  onNavigate,
  cartItems,
  onRemoveItem,
  onUpdateCartQuantity,
  onCheckout
}: CartScreenProps) {
  // Coupon state
  const [coupon, setCoupon] = useState("");
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponFeedback, setCouponFeedback] = useState("");

  // Checkout address state (prefilled delightfully for zero-friction testing)
  const [address, setAddress] = useState({
    fullName: "Nikhil Nimje",
    phoneNumber: "+1 (555) 732-2917",
    addressLine: "452 Neon Sprint Boulevard, Applet Suite 3B",
    city: "Seattle, WA",
    zipCode: "98101"
  });

  const [shippingError, setShippingError] = useState("");
  const [checkoutStep, setCheckoutStep] = useState<"cart" | "address">("cart");
  const [placingOrder, setPlacingOrder] = useState(false);

  // Math equations
  const subtotal = useMemo(() => {
    return cartItems.reduce((acc, item) => acc + item.shoe.price * item.quantity, 0);
  }, [cartItems]);

  const discountAmount = useMemo(() => {
    return Math.round((subtotal * discountPercent) / 100);
  }, [subtotal, discountPercent]);

  const deliveryPrice = subtotal > 150 || subtotal === 0 ? 0 : 15;
  const grandTotal = subtotal + deliveryPrice - discountAmount;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const c = coupon.trim().toUpperCase();
    if (c === "ORBIT20") {
      setDiscountPercent(20);
      setCouponFeedback("Coupon 'ORBIT20' active: 20% Discount applied!");
    } else if (c === "SNEAKER10") {
      setDiscountPercent(10);
      setCouponFeedback("Coupon 'SNEAKER10' active: 10% Discount applied!");
    } else {
      setDiscountFeedbackError("Invalid coupon code.");
    }
  };

  const setDiscountFeedbackError = (msg: string) => {
    setCouponFeedback(msg);
    setTimeout(() => {
      setCouponFeedback("");
    }, 3000);
  };

  const handleProceedToAddress = () => {
    if (cartItems.length === 0) return;
    setCheckoutStep("address");
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.fullName || !address.addressLine || !address.city || !address.zipCode || !address.phoneNumber) {
      setShippingError("Please fulfill all shipping variables above.");
      return;
    }

    setPlacingOrder(true);
    setShippingError("");

    setTimeout(() => {
      onCheckout(address);
      setPlacingOrder(false);
      onNavigate("ORDERS"); // takes them right into tracking
    }, 1800);
  };

  return (
    <div id="cart-screen-wrapper" className="space-y-6 pb-20 min-h-[70vh]">
      
      {/* HEADER CONTROLS */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <button
            id="btn-cart-back"
            onClick={() => {
              if (checkoutStep === "address") {
                setCheckoutStep("cart");
              } else {
                onNavigate("HOME");
              }
            }}
            className="p-2 rounded-xl bg-white/5 border border-white/10 text-zinc-400 hover:text-white transition-all hover:bg-white/10 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-display text-xl font-bold text-white tracking-tight">
              {checkoutStep === "cart" ? "Shopping Cart" : "Shipping Destination"}
            </h1>
            <span className="text-zinc-500 text-xs font-mono">
              {cartItems.length} styles ready
            </span>
          </div>
        </div>
      </div>

      {cartItems.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600">
            <ShoppingBag className="w-8 h-8 text-neutral-600" />
          </div>
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-white">Your Cart is Vacant</h3>
            <p className="text-zinc-500 text-xs max-w-xs">
              Take a walk through our newly released line of crimson runners, vintage courts, or trail blazers.
            </p>
          </div>
          <button
            onClick={() => onNavigate("PLP")}
            className="bg-white text-zinc-950 hover:bg-rose-500 hover:text-white text-xs font-bold py-3 px-6 rounded-xl transition-all font-display uppercase tracking-wider cursor-pointer"
          >
            Browse Products
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* LEFT AREA: CART LIST OR SHIPPING ADDRESS */}
          <div className="lg:col-span-2 space-y-5">
            <AnimatePresence mode="wait">
              {checkoutStep === "cart" ? (
                <motion.div
                  key="cart-list-step"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-3"
                >
                  <span className="text-[10px] font-mono tracking-wider uppercase text-zinc-500 font-bold block mb-1">Basket Contents</span>
                  
                  {cartItems.map((item) => {
                    const itemSubtotal = item.shoe.price * item.quantity;
                    return (
                      <div
                        key={item.id}
                        className="glass-panel rounded-2xl p-4 flex gap-4 items-center justify-between group hover:border-white/20 transition-all duration-300"
                      >
                        {/* Shoe Pic */}
                        <div className="w-16 h-16 bg-[#020617]/40 border border-white/5 rounded-lg flex items-center justify-center p-2 shrink-0">
                          <img
                            src={item.shoe.images[0]}
                            alt={item.shoe.name}
                            className="max-h-full max-w-full object-contain -rotate-6"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Mid Meta details */}
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <span className="text-[10px] text-blue-450 uppercase font-mono tracking-wider font-semibold">{item.shoe.brand}</span>
                          <h4 
                            onClick={() => onNavigate("PDP", { shoeId: item.shoe.id })}
                            className="font-display text-xs md:text-sm font-bold text-white truncate hover:text-blue-400 cursor-pointer"
                          >
                            {item.shoe.name}
                          </h4>
                          <div className="flex flex-wrap items-center gap-x-2 text-[10px] text-zinc-400">
                            <span className="font-mono">Men's US <span className="text-white font-bold">{item.selectedSize}</span></span>
                            <span className="text-zinc-700">•</span>
                            <span className="flex items-center gap-1">
                              Color <span className="text-white font-semibold">{item.selectedColor}</span>
                            </span>
                          </div>
                        </div>

                        {/* Interactive Quantity Box */}
                        <div className="flex items-center gap-1.5 bg-[#020617]/30 p-1 rounded-lg border border-white/10">
                          <button
                            onClick={() => onUpdateCartQuantity(item.id, Math.max(1, item.quantity - 1))}
                            className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-xs font-bold text-white font-mono">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateCartQuantity(item.id, item.quantity + 1)}
                            className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        {/* Price Details */}
                        <div className="text-right shrink-0 space-y-1 pl-2">
                          <div className="text-blue-400 font-display font-extrabold text-sm md:text-md">
                            ${itemSubtotal}
                          </div>
                          
                          <button
                            onClick={() => onRemoveItem(item.id)}
                            className="text-zinc-500 hover:text-rose-500 p-1 rounded hover:bg-rose-500/10 transition-all inline-flex items-center"
                            title="Remove style"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </motion.div>
              ) : (
                <motion.div
                  key="address-step"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="space-y-4"
                >
                  <div className="glass-panel p-5 rounded-2xl max-w-lg space-y-4">
                    <h2 className="font-display text-md font-bold text-white uppercase italic tracking-tight mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-blue-400" />
                      Recipient Address Details
                    </h2>

                    <form onSubmit={handlePlaceOrder} className="space-y-3.5 text-zinc-350 text-xs">
                      
                      {/* Name input */}
                      <div className="space-y-1">
                        <label className="text-[10px] text-zinc-500 uppercase font-mono block">Recipient Full Name</label>
                        <input
                          type="text"
                          required
                          value={address.fullName}
                          onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                          className="w-full bg-[#020617]/50 p-3 rounded-lg border border-white/10 text-white focus:outline-none focus:border-blue-500/80 transition-all font-sans"
                        />
                      </div>

                      {/* Phone input */}
                      <div className="space-y-1">
                        <label className="text-[10px] text-zinc-550 uppercase font-mono block">Mobile Number</label>
                        <input
                          type="text"
                          required
                          value={address.phoneNumber}
                          onChange={(e) => setAddress({ ...address, phoneNumber: e.target.value })}
                          className="w-full bg-[#020617]/50 p-3 rounded-lg border border-white/10 text-white focus:outline-none focus:border-blue-500/80 transition-all font-sans"
                        />
                      </div>

                      {/* Address Line */}
                      <div className="space-y-1">
                        <label className="text-[10px] text-zinc-550 uppercase font-mono block">Street Delivery Address</label>
                        <input
                          type="text"
                          required
                          value={address.addressLine}
                          onChange={(e) => setAddress({ ...address, addressLine: e.target.value })}
                          className="w-full bg-[#020617]/50 p-3 rounded-lg border border-white/10 text-white focus:outline-none focus:border-blue-500/80 transition-all font-sans"
                        />
                      </div>

                      {/* City State Zip */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-[10px] text-zinc-550 uppercase font-mono block">City & State</label>
                          <input
                            type="text"
                            required
                            value={address.city}
                            onChange={(e) => setAddress({ ...address, city: e.target.value })}
                            className="w-full bg-[#020617]/50 p-3 rounded-lg border border-white/10 text-white focus:outline-none focus:border-blue-500/80 transition-all"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] text-zinc-550 uppercase font-mono block">ZIP Code</label>
                          <input
                            type="text"
                            required
                            value={address.zipCode}
                            onChange={(e) => setAddress({ ...address, zipCode: e.target.value })}
                            className="w-full bg-[#020617]/50 p-3 rounded-lg border border-white/10 text-white focus:outline-none focus:border-blue-500/80 transition-all"
                          />
                        </div>
                      </div>

                      {shippingError && (
                        <div className="text-rose-400 text-xs font-semibold">{shippingError}</div>
                      )}

                      <button
                        id="btn-complete-checkout"
                        type="submit"
                        disabled={placingOrder}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-550 hover:to-purple-550 text-white text-xs font-bold py-4 px-4 rounded-xl shadow-lg shadow-blue-500/20 transition-all active:scale-[0.98] mt-4 flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider font-display"
                      >
                        {placingOrder ? (
                          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        ) : (
                          <>
                            Complete Purchase (${grandTotal}) <CheckCircle className="w-4 h-4" />
                          </>
                        )}
                      </button>

                    </form>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* RIGHT AREA: PRICING BREAKDOWN */}
          <div className="lg:col-span-1">
            <div className="glass-panel p-5 rounded-2xl space-y-4">
              <h3 className="font-display text-sm font-bold uppercase tracking-wider text-white border-b border-white/10 pb-2.5">
                Summary of Expenses
              </h3>

              {/* Price list */}
              <div className="space-y-2 text-xs text-zinc-400">
                <div className="flex justify-between items-center">
                  <span>Footwear Value</span>
                  <span className="text-white font-mono font-bold">${subtotal}</span>
                </div>

                {discountPercent > 0 && (
                  <div className="flex justify-between items-center text-rose-400">
                    <span>Coupon Reward ({discountPercent}%)</span>
                    <span className="font-mono font-bold">-${discountAmount}</span>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <span>State Duties & Sales Tax</span>
                  <span className="text-zinc-600 font-mono font-medium">Included</span>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <span>Speedy Aero Dispatch</span>
                    {subtotal > 150 && (
                      <span className="text-[9px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-1 ml-1.5 rounded uppercase font-semibold font-mono">
                        FREE OVER $150
                      </span>
                    )}
                  </div>
                  <span className="text-white font-mono font-bold">
                    {deliveryPrice === 0 ? "FREE" : `$${deliveryPrice}`}
                  </span>
                </div>

                <div className="h-[1px] bg-zinc-800 my-2" />                <div className="flex justify-between items-center text-white text-sm font-bold pt-1">
                  <span>Grand Ultimate Total</span>
                  <span className="text-blue-400 font-display font-extrabold text-base">${grandTotal}</span>
                </div>
              </div>

              {/* Promo Coupon form */}
              {checkoutStep === "cart" && (
                <form onSubmit={handleApplyCoupon} className="space-y-2 pt-2 border-t border-white/5">
                  <span className="text-[10px] uppercase font-mono text-zinc-500 block">Apply Promotional Coupon</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. ORBIT20"
                      value={coupon}
                      onChange={(e) => setCoupon(e.target.value)}
                      className="flex-1 bg-[#020617]/45 p-2.5 rounded-lg border border-white/10 text-xs uppercase focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 rounded-lg cursor-pointer transition-colors shrink-0"
                    >
                      Apply
                    </button>
                  </div>
                  {couponFeedback && (
                    <p className={`text-[10px] font-semibold ${couponFeedback.includes("active") ? "text-blue-400 animate-pulse" : "text-rose-400"}`}>
                      {couponFeedback}
                    </p>
                  )}
                  {discountPercent === 0 && (
                    <span className="text-[9px] text-zinc-500 font-mono block italic leading-none">
                      Tip: Write **ORBIT20** to test 20% off coupon reward.
                    </span>
                  )}
                </form>
              )}

              {/* Sequential action trigger */}
              {checkoutStep === "cart" && (
                <button
                  id="btn-proceed-checkout"
                  onClick={handleProceedToAddress}
                  className="w-full flex items-center justify-center gap-1.5 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white text-xs font-bold py-4 rounded-xl shadow-lg hover:shadow-blue-500/20 transition-all font-display uppercase tracking-wider cursor-pointer"
                >
                  Proceed to Checkout <ChevronRight className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
