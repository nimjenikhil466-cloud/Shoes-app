/**
 * Common Types for Footwear E-Commerce Store
 */

export enum AppScreen {
  LOGIN = "LOGIN",
  HOME = "HOME",
  PLP = "PLP",      // Product Listing Page
  PDP = "PDP",      // Product Details Page
  CART = "CART",    // Shopping Cart & Checkout
  ORDERS = "ORDERS" // Order Status & Step Tracking
}

export interface Shoe {
  id: string;
  name: string;
  brand: string;
  category: "Sneakers" | "Formal" | "Sports" | "Casual";
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  description: string;
  images: string[]; // multi-angle images
  sizes: number[];  // available sizes (US)
  colors: { name: string; hex: string }[];
  featured?: boolean;
  trending?: boolean;
  bannerImage?: string;
  details: {
    material: string;
    care: string;
    returns: string;
  };
}

export interface CartItem {
  id: string; // unique for this purchase state (e.g. shoeId-size-color)
  shoe: Shoe;
  selectedSize: number;
  selectedColor: string;
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  date: string;
  expectedDelivery: string;
  step: OrderStep;
  address: {
    fullName: string;
    phoneNumber: string;
    addressLine: string;
    city: string;
    zipCode: string;
  };
}

export enum OrderStep {
  ORDERED = 0,
  PACKED = 1,
  SHIPPED = 2,
  DELIVERED_OUT = 3,
  DELIVERED = 4
}

export interface FilterOptions {
  sizes: number[];
  brands: string[];
  colors: string[];
  categories: string[];
  priceRange: [number, number];
  sortBy: "popular" | "price-asc" | "price-desc" | "rating";
}
